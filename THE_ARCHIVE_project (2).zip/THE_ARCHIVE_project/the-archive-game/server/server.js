"use strict";

const path = require("path");
const fs = require("fs");
const express = require("express");
const cors = require("cors");

const app = express();
app.use(cors());
app.use(express.json({ limit: "5mb" }));

const PORT = process.env.PORT || 3000;

// ---- "Database" (JSON file) ----
// This avoids native sqlite builds (safer across Node versions).
const DATA_DIR = path.join(__dirname, "data");
const DB_FILE = path.join(DATA_DIR, "saves.json");
fs.mkdirSync(DATA_DIR, { recursive: true });

function readDB(){
  try{
    const raw = fs.readFileSync(DB_FILE, "utf-8");
    const db = JSON.parse(raw);
    if(!db || typeof db !== "object") return { autosave: null, slots: {} };
    db.slots ??= {};
    return db;
  }catch(e){
    return { autosave: null, slots: {} };
  }
}
function writeDB(db){
  fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2), "utf-8");
}

// ---- API ----
app.get("/api/ping", (req,res)=>res.json({ ok:true, name:"THE ARCHIVE", ts: Date.now() }));

// key = "autosave" or 1..3
app.get("/api/save/:key", (req,res)=>{
  const key = req.params.key;
  const db = readDB();
  const data = (key === "autosave") ? db.autosave : db.slots[key] || null;
  res.json({ ok:true, key, data });
});

app.post("/api/save/:key", (req,res)=>{
  const key = req.params.key;
  const payload = req.body?.data ?? null;
  if(!payload) return res.status(400).json({ ok:false, error:"Missing body.data" });

  const db = readDB();
  if(key === "autosave") db.autosave = payload;
  else db.slots[key] = payload;
  db.updatedAt = Date.now();
  writeDB(db);

  res.json({ ok:true, key, ts: db.updatedAt });
});

app.get("/api/latest-slot", (req,res)=>{
  const db = readDB();
  // return 0 for autosave, or 1..3, or null
  let best = { slot: null, ts: 0 };
  if(db.autosave?.ts && db.autosave.ts > best.ts) best = { slot: 0, ts: db.autosave.ts };
  for(const k of Object.keys(db.slots||{})){
    const s = db.slots[k];
    if(s?.ts && s.ts > best.ts) best = { slot: Number(k), ts: s.ts };
  }
  res.json({ ok:true, slot: best.slot });
});

// ---- static client ----
const CLIENT_DIR = path.join(__dirname, "..", "client");
app.use(express.static(CLIENT_DIR));
app.get("*", (req,res)=> res.sendFile(path.join(CLIENT_DIR, "index.html")));

app.listen(PORT, ()=>{
  console.log(`THE ARCHIVE server running on http://localhost:${PORT}`);
});
