# THE ARCHIVE (Web Game)

## Run (with database)
1) Install Node.js (18+ recommended)
2) In this folder:
   - `npm install`
   - `npm start`
3) Open: http://localhost:5173

## Files
- `client/` : index.html + style.css + main.js (game) + api.js (remote save helper)
- `server/` : Express + SQLite API (saves stored in `server/data/game.db`)

## Notes
- The game still works offline using `localStorage`.
- When the server is running, it will also sync saves to SQLite automatically (best effort).
