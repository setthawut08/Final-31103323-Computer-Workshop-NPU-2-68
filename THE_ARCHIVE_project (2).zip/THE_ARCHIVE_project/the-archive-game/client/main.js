
"use strict";

/* =========================================================
  THE ARCHIVE: FULL SYSTEM (Single-file)
  - Multi chapters (3)
  - Menu/Settings/SaveLoad/ChapterSelect
  - Hold-to-interact
  - Inventory + Notes + QuestLog
  - Flashlight battery + Calm focus
  - Enemy AI: Hearing + Vision + Investigate/Chase/Search + Lost target
  - Hiding spots
  - Spook triggers (zones / one-time)
  - Door: key / code lock
  - Autosave timer + manual slots
========================================================= */

/* ===================== UTIL ===================== */
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
const lerp=(a,b,t)=>a+(b-a)*t;
const rand=(a,b)=>a+Math.random()*(b-a);
const now=()=>performance.now();
const dist=(ax,ay,bx,by)=>Math.hypot(ax-bx,ay-by);
const rectContains=(r,x,y)=> x>=r.x && y>=r.y && x<=r.x+r.w && y<=r.y+r.h;

/* ===================== AUDIO (WebAudio synth) ===================== */
const AudioSys={
  ctx:null, master:null, sfx:null, amb:null, drone:null,
  lastBeatFear:0, beatTimer:0,

  ensure(){
    const AC = window.AudioContext || window.webkitAudioContext;
    if(!this.ctx) this.ctx = new AC();
    if(!this.master){
      this.master = this.ctx.createGain();
      this.sfx = this.ctx.createGain();
      this.amb = this.ctx.createGain();
      this.sfx.connect(this.master);
      this.amb.connect(this.master);
      this.master.connect(this.ctx.destination);
    }
    this.applySettings(Settings.data);
  },
  applySettings(cfg){
    if(!cfg || !this.master) return;
    const mute = !!cfg.audio.mute;
    this.master.gain.value = mute ? 0 : cfg.audio.master;
    this.sfx.gain.value = cfg.audio.sfx;
    this.amb.gain.value = cfg.audio.amb;
  },
  tone(freq=440,type="sine",dur=0.08,vol=0.12, out="sfx"){
    if(!this.ctx) return;
    const osc=this.ctx.createOscillator();
    const g=this.ctx.createGain();
    osc.type=type; osc.frequency.value=freq;
    g.gain.value=vol;
    g.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime+dur);
    osc.connect(g);
    g.connect(out==="amb" ? this.amb : this.sfx);
    osc.start(); osc.stop(this.ctx.currentTime+dur);
  },
  noise(dur=0.08,vol=0.08,cut=600){
    if(!this.ctx) return;
    const len = Math.floor(this.ctx.sampleRate*dur);
    const buf = this.ctx.createBuffer(1,len,this.ctx.sampleRate);
    const data = buf.getChannelData(0);
    for(let i=0;i<len;i++) data[i]=Math.random()*2-1;
    const src=this.ctx.createBufferSource(); src.buffer=buf;

    const f=this.ctx.createBiquadFilter();
    f.type="lowpass"; f.frequency.value=cut;

    const g=this.ctx.createGain();
    g.gain.value=vol;
    g.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime+dur);

    src.connect(f); f.connect(g); g.connect(this.sfx);
    src.start();

},
// ===== Spatial helpers (pseudo 3D) =====
_gainPanTo(outNode, gainVal=0.2, panVal=0){
  if(!this.ctx) return null;
  const g=this.ctx.createGain(); g.gain.value=gainVal;
  // StereoPanner may not exist on older browsers; fallback to gain only
  const P = this.ctx.createStereoPanner ? this.ctx.createStereoPanner() : null;
  if(P){
    P.pan.value = clamp(panVal, -1, 1);
    g.connect(P); P.connect(outNode);
    return { g, p:P };
  }else{
    g.connect(outNode);
    return { g, p:null };
  }
},
// volume attenuates with distance, pan depends on dx
_spatial(px,py, baseVol=0.25, maxDist=520){
  // if player not ready, return base
  const dx = (typeof Player!=="undefined") ? (px-Player.x) : 0;
  const dy = (typeof Player!=="undefined") ? (py-Player.y) : 0;
  const d = Math.hypot(dx,dy);
  const att = clamp(1 - d/maxDist, 0.05, 1);
  const pan = clamp(dx/260, -1, 1);
  return { vol: baseVol*att, pan, d };
},
dripAt(x,y){
  if(!this.ctx) return;
  const s=this._spatial(x,y, 0.30, 620);
  const chain=this._gainPanTo(this.amb, s.vol, s.pan);
  // drip = short "plop": sine pitch fall + tiny noise click
  const t=this.ctx.currentTime;
  const osc=this.ctx.createOscillator();
  osc.type="sine";
  osc.frequency.setValueAtTime(520, t);
  osc.frequency.exponentialRampToValueAtTime(180, t+0.08);
  const g=this.ctx.createGain();
  g.gain.setValueAtTime(0.001, t);
  g.gain.exponentialRampToValueAtTime(0.12, t+0.01);
  g.gain.exponentialRampToValueAtTime(0.001, t+0.10);

  const lp=this.ctx.createBiquadFilter();
  lp.type="lowpass"; lp.frequency.value=1200;

  osc.connect(lp); lp.connect(g); g.connect(chain.g);
  osc.start(); osc.stop(t+0.12);

  // click noise
  const len = Math.floor(this.ctx.sampleRate*0.03);
  const buf = this.ctx.createBuffer(1,len,this.ctx.sampleRate);
  const data = buf.getChannelData(0);
  for(let i=0;i<len;i++) data[i]=(Math.random()*2-1) * (1 - i/len);
  const src=this.ctx.createBufferSource(); src.buffer=buf;
  const hp=this.ctx.createBiquadFilter(); hp.type="highpass"; hp.frequency.value=800;
  const ng=this.ctx.createGain(); ng.gain.value=0.10;
  src.connect(hp); hp.connect(ng); ng.connect(chain.g);
  src.start(t);
},
whisperAt(x,y){
  if(!this.ctx) return;
  const s=this._spatial(x,y, 0.22, 680);
  const chain=this._gainPanTo(this.amb, s.vol, s.pan);

  // breathy filtered noise with slow LFO
  const dur=0.55;
  const len=Math.floor(this.ctx.sampleRate*dur);
  const buf=this.ctx.createBuffer(1,len,this.ctx.sampleRate);
  const ch=buf.getChannelData(0);
  for(let i=0;i<len;i++){
    const t=i/this.ctx.sampleRate;
    const env = Math.exp(-t*2.8);
    ch[i] = (Math.random()*2-1) * env;
  }
  const src=this.ctx.createBufferSource(); src.buffer=buf;

  const bp=this.ctx.createBiquadFilter();
  bp.type="bandpass"; bp.frequency.value=520; bp.Q.value=1.2;

  const g=this.ctx.createGain();
  g.gain.value=0.001;
  const now=this.ctx.currentTime;
  g.gain.exponentialRampToValueAtTime(0.20, now+0.05);
  g.gain.exponentialRampToValueAtTime(0.001, now+dur);

  src.connect(bp); bp.connect(g); g.connect(chain.g);
  src.start(now);
},

startDrone(){
    if(!this.ctx || this.drone) return;
    const osc=this.ctx.createOscillator();
    osc.type="sawtooth";
    osc.frequency.value=45;

    const filt=this.ctx.createBiquadFilter();
    filt.type="lowpass";
    filt.frequency.value=280;

    const lfo=this.ctx.createOscillator();
    lfo.type="sine"; lfo.frequency.value=0.08;
    const lfoG=this.ctx.createGain(); lfoG.gain.value=160;
    lfo.connect(lfoG); lfoG.connect(filt.frequency);

    const g=this.ctx.createGain(); g.gain.value=0.06;

    osc.connect(filt); filt.connect(g); g.connect(this.amb);

    osc.start(); lfo.start();
    this.drone=osc;
  },
  heartbeat(dt,fear){
    if(!this.ctx) return;
    const reduce = Settings.data.game.reduceFlashes;
    if(fear<20){ document.getElementById("heart").style.boxShadow="none"; this.beatTimer=0; return; }

    const interval = clamp(1.1 - fear/120, 0.18, 1.0);
    this.beatTimer += dt;
    const inten = fear/100;

    const overlay = reduce ? inten*0.22 : inten;
    document.getElementById("heart").style.boxShadow =
      `inset 0 0 ${overlay*150}px ${overlay*55}px rgba(138,0,0,${overlay*0.4})`;

    if(this.beatTimer >= interval){
      this.beatTimer = 0;
      this.tone(60,"sine",0.10,0.14);
      this.tone(35,"sine",0.10,0.10);
    }
  }
};

/* ===================== INPUT ===================== */
const Input={
  k:{}, just:{},
  init(){
    window.addEventListener("keydown",(e)=>{
      if(!this.k[e.code]) this.just[e.code]=true;
      this.k[e.code]=true;

      if(e.code==="Tab"){ e.preventDefault(); UI.toggleDrawer("journal"); }
      if(e.code==="KeyJ"){ UI.toggleDrawer("journal"); }
      if(e.code==="KeyI"){ UI.toggleDrawer("inventory"); }
      if(e.code==="Escape"){ Game.togglePause(); }
      if(e.code==="F3"){ UI.debug = !UI.debug; document.getElementById("debug").style.display = UI.debug ? "block" : "none"; }
      if(e.code==="KeyF"){ if(Game.state==="PLAY") Flashlight.toggle(); }
      if(e.code==="KeyE"){ if(Game.state==="PLAY") InteractHold.begin(); }
      if(e.code==="KeyC"){ if(Game.state==="PLAY") Focus.begin(); }
    },{passive:false});

    window.addEventListener("keyup",(e)=>{
      this.k[e.code]=false;
      if(e.code==="KeyE") InteractHold.cancel();
      if(e.code==="KeyC") Focus.end();
    });
  },
  consumeJust(code){
    const v=!!this.just[code];
    this.just[code]=false;
    return v;
  }
};

/* ===================== SETTINGS ===================== */
const Settings={
  key:"archive_settings_full_v1",
  defaults:{
    lang:"th",
    video:{ fullscreen:false, renderScale:1.00, pixelate:false, brightness:1.00, contrast:1.00, grain:0.35, scanlines:true, fog:0.85, shake:1.00 },
    audio:{ master:0.60, sfx:0.70, amb:0.50, mute:false },
    game:{ reduceFlashes:false, autoPause:true, showMarker:true, difficulty:"normal" }
  },
  data:null, pending:null, dirty:false,

  load(){
    let saved=null;
    try{ saved=JSON.parse(localStorage.getItem(this.key)||"null"); }catch(e){}
    this.data = this.merge(structuredClone(this.defaults), saved||{});
    this.pending = structuredClone(this.data);
    this.apply(this.data,true);
  },
  save(){ localStorage.setItem(this.key, JSON.stringify(this.data)); },
  merge(a,b){
    if(!b || typeof b!=="object") return a;
    for(const k of Object.keys(b)){
      if(b[k] && typeof b[k]==="object" && !Array.isArray(b[k])) a[k]=this.merge(a[k]||{}, b[k]);
      else a[k]=b[k];
    }
    return a;
  },
  setDirty(v){
    this.dirty=v;
    document.getElementById("setDirty").style.opacity = v ? "0.85" : "0";
  },
  apply(cfg,isBoot=false){
    // canvas filter
    document.getElementById("root").style.filter = `brightness(${cfg.video.brightness}) contrast(${cfg.video.contrast})`;
    // post grain
    document.getElementById("post").style.opacity = String(cfg.video.grain);
    // scanlines
    document.getElementById("scanlines").style.display = cfg.video.scanlines ? "block" : "none";
    // render scale & pixel
    Game.renderScale = cfg.video.renderScale;
    Game.pixelate = cfg.video.pixelate;
    if(!isBoot) Game.resize();

    Game.fogMult = cfg.video.fog;
    Game.shakeMult = cfg.video.shake;

    // audio
    AudioSys.applySettings(cfg);

    // marker toggle
    UI.showMarker = cfg.game.showMarker;

    // language
    document.documentElement.lang = cfg.lang || "en";
    UI.applyLanguage?.(cfg.lang || "en");
  },
  open(){
    this.pending = structuredClone(this.data);
    this.setDirty(false);
    this.fillUI(this.pending);
  },
  applyPending(){
    this.data = structuredClone(this.pending);
    this.apply(this.data);
    this.save();
    this.setDirty(false);
    this.applyFullscreen(this.data.video.fullscreen);
  },
  discard(){
    this.pending = structuredClone(this.data);
    this.apply(this.data);
    this.setDirty(false);
  },
  reset(){
    this.pending = structuredClone(this.defaults);
    this.fillUI(this.pending);
    this.preview();
  },
  preview(){ this.apply(this.pending); this.setDirty(true); },
  applyFullscreen(want){
    try{
      if(want && !document.fullscreenElement) document.documentElement.requestFullscreen?.();
      if(!want && document.fullscreenElement) document.exitFullscreen?.();
    }catch(e){}
  },
  setPath(obj,path,val){
    const p=path.split(".");
    let cur=obj;
    for(let i=0;i<p.length-1;i++){ cur[p[i]] ??= {}; cur = cur[p[i]]; }
    cur[p[p.length-1]] = val;
  },
  fillUI(cfg){
    const setRange=(id,v,fmt)=>{ const el=document.getElementById(id); const out=document.getElementById("v_"+id.slice(2)); if(el) el.value=v; if(out) out.textContent=fmt(v); };
    const setToggle=(id,v)=>{ const el=document.getElementById(id); if(el) el.checked=!!v; };
    const setSelect=(id,v)=>{ const el=document.getElementById(id); if(el) el.value=v; };

    setToggle("s_full", cfg.video.fullscreen);
    setRange("s_scale", cfg.video.renderScale, x=>`${Math.round(x*100)}%`);
    setToggle("s_pixel", cfg.video.pixelate);
    setRange("s_bri", cfg.video.brightness, x=>x.toFixed(2));
    setRange("s_con", cfg.video.contrast, x=>x.toFixed(2));
    setRange("s_grain", cfg.video.grain, x=>`${Math.round(x*100)}%`);
    setToggle("s_scan", cfg.video.scanlines);
    setRange("s_fog", cfg.video.fog, x=>x.toFixed(2));
    setRange("s_shake", cfg.video.shake, x=>`${Math.round(x*100)}%`);

    setRange("s_master", cfg.audio.master, x=>`${Math.round(x*100)}%`);
    setRange("s_sfx", cfg.audio.sfx, x=>`${Math.round(x*100)}%`);
    setRange("s_amb", cfg.audio.amb, x=>`${Math.round(x*100)}%`);
    setToggle("s_mute", cfg.audio.mute);

    setSelect("s_lang", cfg.lang);

    setToggle("s_reduce", cfg.game.reduceFlashes);
    setToggle("s_autopause", cfg.game.autoPause);
    setToggle("s_marker", cfg.game.showMarker);
    setSelect("s_diff", cfg.game.difficulty);
  },
  bindUI(){
    // tabs
    document.querySelectorAll("#screenSettings .tab").forEach(btn=>{
      btn.addEventListener("click",()=>{
        document.querySelectorAll("#screenSettings .tab").forEach(b=>b.classList.remove("active"));
        btn.classList.add("active");
        const tab=btn.dataset.tab;
        document.querySelectorAll("#screenSettings .page").forEach(p=>p.classList.remove("active"));
        document.getElementById(`tab-${tab}`)?.classList.add("active");
      });
    });

    const bindRange=(id,path,fmt)=>{
      const el=document.getElementById(id); const out=document.getElementById("v_"+id.slice(2));
      el.addEventListener("input",()=>{
        const v=parseFloat(el.value);
        Settings.setPath(Settings.pending,path,v);
        if(out) out.textContent = fmt(v);
        Settings.preview();
      });
    };
    const bindToggle=(id,path)=>{
      const el=document.getElementById(id);
      el.addEventListener("change",()=>{
        Settings.setPath(Settings.pending,path,!!el.checked);
        Settings.preview();
      });
    };
    const bindSelect=(id,path)=>{
      const el=document.getElementById(id);
      el.addEventListener("change",()=>{
        Settings.setPath(Settings.pending,path,el.value);
        Settings.preview();
      });
    };

    bindToggle("s_full","video.fullscreen");
    bindRange("s_scale","video.renderScale",v=>`${Math.round(v*100)}%`);
    bindToggle("s_pixel","video.pixelate");
    bindRange("s_bri","video.brightness",v=>v.toFixed(2));
    bindRange("s_con","video.contrast",v=>v.toFixed(2));
    bindRange("s_grain","video.grain",v=>`${Math.round(v*100)}%`);
    bindToggle("s_scan","video.scanlines");
    bindRange("s_fog","video.fog",v=>v.toFixed(2));
    bindRange("s_shake","video.shake",v=>`${Math.round(v*100)}%`);

    bindRange("s_master","audio.master",v=>`${Math.round(v*100)}%`);
    bindRange("s_sfx","audio.sfx",v=>`${Math.round(v*100)}%`);
    bindRange("s_amb","audio.amb",v=>`${Math.round(v*100)}%`);
    bindToggle("s_mute","audio.mute");

    bindSelect("s_lang","lang");
    bindToggle("s_reduce","game.reduceFlashes");
    bindToggle("s_autopause","game.autoPause");
    bindToggle("s_marker","game.showMarker");
    bindSelect("s_diff","game.difficulty");

    document.getElementById("btnTestSfx").addEventListener("click",()=>{
      AudioSys.ensure();
      AudioSys.tone(520,"square",0.10,0.16);
      AudioSys.noise(0.08,0.12,650);
    });

    document.getElementById("btnSetReset").addEventListener("click",()=>Settings.reset());
    document.getElementById("btnSetApply").addEventListener("click",()=>Settings.applyPending());
    document.getElementById("btnSetBack").addEventListener("click",()=>{
      Settings.discard();
      UI.showScreen("menu");
    });

    document.addEventListener("visibilitychange",()=>{
      if(!Settings.data.game.autoPause) return;
      if(document.hidden && Game.state==="PLAY") Game.setPause(true);
    });
  }
};


/* ===================== REMOTE SYNC (SQLite server optional) ===================== */
const RemoteSync = {
  // cache keys for remote data in localStorage (so existing sync flow remains mostly unchanged)
  cacheKey(slot){ return `archive_remote_cache_slot_${slot}`; },
  cacheKeyAutosave(){ return "archive_remote_cache_autosave"; },

  async warmup(){
    // Fetch latest remote save and cache it (best effort)
    try{
      if(!window.RemoteDB || !RemoteDB.enabled) return;
      const latest = await RemoteDB.latestSlot();
      if(latest === null) return;
      const data = await RemoteDB.load(latest === 0 ? "autosave" : latest);
      if(data){
        localStorage.setItem(latest === 0 ? this.cacheKeyAutosave() : this.cacheKey(latest), JSON.stringify(data));
      }
    }catch(e){}
  },

  stash(slot, data){
    try{
      localStorage.setItem(slot === 0 ? this.cacheKeyAutosave() : this.cacheKey(slot), JSON.stringify(data));
    }catch(e){}
    // send to server in background
    try{
      if(window.RemoteDB && RemoteDB.enabled){
        RemoteDB.save(slot === 0 ? "autosave" : slot, data);
      }
    }catch(e){}
  },

  pullCache(slot){
    try{
      const raw = localStorage.getItem(slot === 0 ? this.cacheKeyAutosave() : this.cacheKey(slot));
      if(!raw) return null;
      return JSON.parse(raw);
    }catch(e){ return null; }
  }
};



/* ===================== I18N (TH/EN) ===================== */
const I18N = {
  en: {
    menu: {
      new:  { label:"NEW GAME", desc:"Begin investigation." },
      continue:{ label:"CONTINUE", desc:"Resume last session." },
      chapter:{ label:"CHAPTER SELECT", desc:"Choose a chapter you have unlocked." },
      settings:{ label:"SETTINGS", desc:"Video • Audio • Language • Gameplay" },
      save:{ label:"SAVE / LOAD", desc:"Manage save slots." },
      exit:{ label:"EXIT GAME", desc:"Leave the archive." }
    },
    hint: { move:"move", sprint:"sprint", hold:"hold", light:"light", calm:"calm", journal:"journal", inventory:"inventory", pause:"pause" },
    hud: { stamina:"stamina", battery:"battery" },
    misc: { chapterPrefix:"CHAPTER", noisePrefix:"NOISE", objectivePrefix:"OBJECTIVE" },
    loading: { sub:"booting • initializing • decrypting records", tip:"tip: sprint makes noise • enemy can hear you" },
    settings: { uiLang:"UI Language", uiLangHint:"Menus & UI text." },
  },
  th: {
    menu: {
      new:  { label:"เริ่มเกมใหม่", desc:"เริ่มการสืบสวน" },
      continue:{ label:"เล่นต่อ", desc:"เล่นต่อจากครั้งล่าสุด" },
      chapter:{ label:"เลือกด่าน", desc:"เลือกด่านที่ปลดล็อกแล้ว" },
      settings:{ label:"ตั้งค่า", desc:"ภาพ • เสียง • ภาษา • เกมเพลย์" },
      save:{ label:"บันทึก / โหลด", desc:"จัดการเซฟเกม" },
      exit:{ label:"ออกจากเกม", desc:"ออกจาก THE ARCHIVE" }
    },
    hint: { move:"เดิน", sprint:"วิ่ง", hold:"กดค้าง", light:"ไฟฉาย", calm:"ตั้งสติ", journal:"บันทึก", inventory:"กระเป๋า", pause:"พักเกม" },
    hud: { stamina:"พลัง", battery:"แบตเตอรี่" },
    misc: { chapterPrefix:"ด่าน", noisePrefix:"เสียง", objectivePrefix:"เป้าหมาย" },
    loading: { sub:"กำลังบูต • กำลังเริ่มระบบ • ถอดรหัสบันทึก", tip:"ทิป: วิ่งจะมีเสียง • ศัตรูได้ยิน" },
    settings: { uiLang:"ภาษาเมนู", uiLangHint:"ข้อความเมนูและ UI" },
  }
};

function curLang(){
  return (Settings?.data?.lang || Settings?.pending?.lang || "en");
}

function t(path){
  const lang = curLang();
  const parts = path.split(".");
  let o = I18N[lang] || I18N.en;
  for(const p of parts){ o = o?.[p]; }
  if(o==null){
    // fallback en
    o = I18N.en;
    for(const p of parts){ o = o?.[p]; }
  }
  return o;
}

/* ===================== SAVE MANAGER ===================== */
const Save={
  prefix:"archive_slot_",
  autosaveKey:"archive_autosave",
  progressKey:"archive_progress",
  lastSlotKey:"archive_lastslot",

  defaultProgress(){
    return { unlocked:[0], lastChapter:0 }; // chapter indices
  },
  getProgress(){
    let p=null;
    try{ p=JSON.parse(localStorage.getItem(this.progressKey)||"null"); }catch(e){}
    if(!p) p=this.defaultProgress();
    // sanitize
    p.unlocked = Array.isArray(p.unlocked) ? p.unlocked : [0];
    p.lastChapter = Number.isFinite(p.lastChapter) ? p.lastChapter : 0;
    return p;
  },
  setProgress(p){ localStorage.setItem(this.progressKey, JSON.stringify(p)); },

  key(slot){ return this.prefix+slot; },
  hasAny(){
    if(localStorage.getItem(this.autosaveKey)) return true;
    for(let i=1;i<=3;i++) if(localStorage.getItem(this.key(i))) return true;
    return false;
  },
  pack(){
    return {
      v:1, ts:Date.now(),
      chapter: Chapter.idx,
      stats: Stats.pack(),
      player: Player.pack(),
      enemy: Enemy.pack(),
      inv: Inventory.pack(),
      journal: Journal.pack(),
      quest: Quest.pack(),
      world: World.pack()
    };
  },
  apply(save){
    Chapter.load(save.chapter ?? 0, true);
    Stats.apply(save.stats || {});
    Player.apply(save.player || {});
    Enemy.apply(save.enemy || {});
    Inventory.apply(save.inv || {});
    Journal.apply(save.journal || {});
    Quest.apply(save.quest || {});
    World.apply(save.world || {});
    UI.refreshAll();
  },
  saveSlot(slot){
    const packed=this.pack();
    localStorage.setItem(this.key(slot), JSON.stringify(packed));
    localStorage.setItem(this.lastSlotKey, String(slot));
    RemoteSync.stash(slot, packed);
  },
  loadSlot(slot){
    // 1) remote cache (if warmup already ran)
    const cached = RemoteSync.pullCache(slot);
    if(cached) return cached;
    // 2) local
    const raw=localStorage.getItem(this.key(slot));
    if(!raw) return null;
    try{ return JSON.parse(raw); }catch(e){ return null; }
  },
  autosave(reason="timer"){
    const data=this.pack();
    data.reason=reason;
    localStorage.setItem(this.autosaveKey, JSON.stringify(data));
    RemoteSync.stash(0, data);
  },
  loadAutosave(){
    const cached = RemoteSync.pullCache(0);
    if(cached) return cached;
    const raw=localStorage.getItem(this.autosaveKey);
    if(!raw) return null;
    try{ return JSON.parse(raw); }catch(e){ return null; }
  },
  latest(){
    let best={slot:null, ts:0};
    const a=this.loadAutosave();
    if(a?.ts && a.ts>best.ts) best={slot:0, ts:a.ts};
    for(let i=1;i<=3;i++){
      const s=this.loadSlot(i);
      if(s?.ts && s.ts>best.ts) best={slot:i, ts:s.ts};
    }
    return best.slot;
  },
  wipeAll(){
    localStorage.removeItem(this.autosaveKey);
    for(let i=1;i<=3;i++) localStorage.removeItem(this.key(i));
  }
};

/* ===================== STATS ===================== */
const Stats={
  playTime:0, scares:0, deaths:0, steps:0,
  reset(){ this.playTime=0; this.scares=0; this.deaths=0; this.steps=0; },
  tick(dt){ this.playTime+=dt; },
  fmt(){
    const s=Math.floor(this.playTime);
    const m=Math.floor(s/60);
    const r=s%60;
    return `${m.toString().padStart(2,"0")}:${r.toString().padStart(2,"0")}`;
  },
  pack(){ return { playTime:this.playTime, scares:this.scares, deaths:this.deaths, steps:this.steps }; },
  apply(d){ this.playTime=d.playTime||0; this.scares=d.scares||0; this.deaths=d.deaths||0; this.steps=d.steps||0; }
};

/* ===================== INVENTORY + JOURNAL ===================== */
const Inventory={
  items:{}, // id -> qty
  reset(){ this.items={}; },
  add(id,qty=1){ this.items[id]=(this.items[id]||0)+qty; UI.refreshInvMini(); UI.refreshDrawer(); },
  has(id,qty=1){ return (this.items[id]||0)>=qty; },
  remove(id,qty=1){ this.items[id]=(this.items[id]||0)-qty; if(this.items[id]<=0) delete this.items[id]; UI.refreshInvMini(); UI.refreshDrawer(); },
  useMedkit(){
    if(!this.has("medkit",1)) return false;
    this.remove("medkit",1);
    Player.fear = Math.max(0, Player.fear-35);
    Game.shake = Math.max(0, Game.shake-20);
    AudioSys.ensure(); AudioSys.tone(520,"sine",0.10,0.14);
    Journal.add(`Used MEDKIT. Fear reduced.`);
    return true;
  },
  listText(){
    const keys=Object.keys(this.items);
    if(!keys.length) return "EMPTY";
    return keys.map(k=>`${k.toUpperCase()} x${this.items[k]}`).join("<br>");
  },
  pack(){ return { items:this.items }; },
  apply(d){ this.items = d.items || {}; }
};

const Journal={
  notes:[],
  reset(){ this.notes=[]; },
  add(text){
    this.notes.push(`[${Chapter.name()}] ${text}`);
    UI.refreshDrawer();
  },
  listText(){
    if(!this.notes.length) return "—";
    return this.notes.slice(-30).map(n=>`<div style="margin-bottom:10px;border-bottom:1px dashed rgba(255,255,255,0.10);padding-bottom:6px;">${n}</div>`).join("");
  },
  pack(){ return { notes:this.notes }; },
  apply(d){ this.notes = Array.isArray(d.notes) ? d.notes : []; }
};

/* ===================== QUEST ===================== */
const Quest={
  list:[],
  resetForChapter(ch){
    // data-driven per chapter
    const def = Chapter.def();
    this.list = def.quests.map(q=>({ ...q }));
    UI.refreshDrawer();
  },
  get(id){ return this.list.find(q=>q.id===id); },
  set(id,patch){
    const q=this.get(id); if(!q) return;
    Object.assign(q,patch);
    UI.refreshDrawer();
  },
  activeText(){
    const a=this.list.filter(q=>q.status==="active");
    const d=this.list.filter(q=>q.status==="done");
    const html = `
      <div style="color:rgba(240,240,240,0.65);letter-spacing:2px;font-size:11px;margin-bottom:6px;">ACTIVE</div>
      ${a.map(q=>`
        <div style="margin-bottom:10px;">
          <div style="color:rgba(240,240,240,0.80);text-transform:uppercase;letter-spacing:2px;font-size:12px;">${(curLang()==="th" && q.thTitle)?q.thTitle:q.title}</div>
          <div style="color:rgba(200,200,200,0.35);font-size:11px;line-height:1.35;">${(curLang()==="th" && q.thDesc)?q.thDesc:q.desc}</div>
        </div>
      `).join("") || `<div style="color:rgba(200,200,200,0.35);font-size:11px;">None</div>`}
      <div style="margin-top:12px;color:rgba(240,240,240,0.65);letter-spacing:2px;font-size:11px;margin-bottom:6px;">COMPLETED</div>
      ${d.map(q=>`<div style="color:rgba(200,200,200,0.35);font-size:11px;letter-spacing:2px;text-transform:uppercase;">✓ ${(curLang()==="th" && q.thTitle)?q.thTitle:q.title}</div>`).join("") || `<div style="color:rgba(200,200,200,0.25);font-size:11px;">None</div>`}
    `;
    return html;
  },
  objectiveText(){
    const a=this.list.find(q=>q.status==="active");
    const L = I18N[curLang()] || I18N.en;
    const prefix = (L.misc?.objectivePrefix || "OBJECTIVE").toUpperCase();
    if(!a) return `${prefix}: —`;
    const title = (curLang()==="th" && a.thTitle) ? a.thTitle : a.title;
    return `${prefix}: ${title}`;
  },
  pack(){ return { list:this.list }; },
  apply(d){ this.list = Array.isArray(d.list) ? d.list : []; }
};

/* ===================== FLASHLIGHT + FOCUS/CALM ===================== */
const Flashlight={
  on:true,
  battery:100,

  // TUNING (เดิม drain=2.8 ทำให้หมด ~36 วิ)
  drainWalk:0.55,        // ต่อวินาที (เดิน/ยืน)
  drainSprint:0.95,      // ต่อวินาที (วิ่ง)
  drainIdle:0.35,        // ต่อวินาที (ยืนเฉยๆ)
  lowAt:20,              // เริ่มกระพริบ
  critAt:8,              // กระพริบหนัก + ดับได้

  reset(){ this.on=true; this.battery=100; },

  toggle(){
    if(this.battery<=0) return;
    this.on=!this.on;
    AudioSys.ensure();
    AudioSys.tone(this.on?700:220,"square",0.06,0.08);
  },

  add(amount){
    this.battery = clamp(this.battery + amount, 0, 100);
    AudioSys.ensure(); AudioSys.tone(520,"sine",0.08,0.10);
  },

  update(dt){
    if(Game.state!=="PLAY") return;

    if(this.on){
      // ปรับการกินแบตตามสถานะการเคลื่อนที่
      const moving = (Math.abs(Player.vx)+Math.abs(Player.vy))>0.01;
      const sprint = !!Player.isSprinting;
      const drain = sprint ? this.drainSprint : (moving ? this.drainWalk : this.drainIdle);

      this.battery -= drain*dt;

      // Low battery: flicker แบบสุ่ม (ทำให้รู้สึกเป็นเกมใหญ่ขึ้น)
      if(this.battery <= this.lowAt && this.battery > 0){
        const p = (this.battery<=this.critAt) ? 0.28 : 0.10; // ความถี่กระพริบ
        if(Math.random() < p*dt){
          // กระพริบ 1 เฟรม
          this.on = false;
          setTimeout(()=>{ if(Game.state==="PLAY" && this.battery>0) this.on = true; }, this.battery<=this.critAt ? 120 : 70);
          AudioSys.ensure();
          AudioSys.noise(0.04, 0.05, 520);
        }
      }

      if(this.battery<=0){ this.battery=0; this.on=false; }
    }

    UI.updateBars();
  }
};

const Focus={
  holding:false, val:100, cooldown:0,
  usePerSec:35, regenPerSec:12, calmPerSec:45, cooldownSec:3.2,

  reset(){ this.holding=false; this.val=100; this.cooldown=0; },
  begin(){ this.holding=true; },
  end(){
    if(this.holding && this.val<100) this.cooldown=Math.max(this.cooldown,this.cooldownSec);
    this.holding=false;
  },
  update(dt){
    if(Game.state!=="PLAY") return;
    if(this.cooldown>0) this.cooldown-=dt;

    if(this.holding && this.cooldown<=0 && this.val>0){
      this.val = Math.max(0, this.val - this.usePerSec*dt);
      Player.fear = Math.max(0, Player.fear - this.calmPerSec*dt);
      Game.shake = Math.max(0, Game.shake - 35*dt);
    }else{
      this.val = Math.min(100, this.val + this.regenPerSec*dt);
    }
    UI.updateBars();
  }
};

/* ===================== INTERACT HOLD ===================== */
const InteractHold={
  holding:false, p:0, dur:0.65, cooldown:0, target:null,
  setTarget(t){ this.target=t; if(!t){ this.p=0; UI.setHold(0); } },
  begin(){ if(this.cooldown>0) return; this.holding=true; },
  cancel(){ this.holding=false; this.p=0; UI.setHold(0); },
  update(dt){
    if(this.cooldown>0) this.cooldown-=dt;
    if(Game.state!=="PLAY"){ this.cancel(); return; }
    if(!this.holding || this.cooldown>0) return;

    const t=this.target;
    if(!t || !World.inInteractRange(t, Player.x, Player.y)){
      this.p=0; UI.setHold(0); return;
    }

    this.p = Math.min(1, this.p + dt/this.dur);
    UI.setHold(this.p);

    if(this.p>=1){
      this.holding=false; this.p=0; UI.setHold(0);
      this.cooldown=0.15;
      Game.interact(t);
    }
  }
};

/* ===================== WORLD + CHAPTER DEFINITIONS ===================== */
const Chapter={
  idx:0,
  defs:[
    {
      id:"forest",
      name:"FOREST PATH",
      size:{ w:2400, h:1800 },
      fog: 1.10,
      ambience: { drone: true, spookChance: 0.00025 },
      playerSpawn:{ x: 2100, y: 1600 },
      enemySpawn:{ x: 350, y: 380 },
      quests:[
        { id:"find_pages", title:"COLLECT PAGES", desc:"Find 3 torn pages in the forest.", status:"active", needPages:3 },
        { id:"exit", title:"ESCAPE", desc:"Reach the exit once pages collected.", status:"locked" }
      ],
      // simple layout
      walls:[
        // borders
        {x:-100,y:-100,w:2600,h:100},{x:-100,y:1800,w:2600,h:100},{x:-100,y:0,w:100,h:1800},{x:2400,y:0,w:100,h:1800},
        // trees / rocks
        {x:520,y:260,w:120,h:520},{x:760,y:460,w:160,h:120},{x:1050,y:280,w:140,h:520},
        {x:1400,y:740,w:500,h:120},{x:1700,y:980,w:120,h:420},
        {x:420,y:1180,w:520,h:120},{x:680,y:1260,w:120,h:360},
      ],
      doors:[
        { id:"forestGate", x: 160, y: 140, w: 90, h: 22, type:"exit", locked:false }
      ],
      exit:{ x: 130, y: 130, r: 70, doorId:"forestGate" },
      items:[
        { id:"page1", type:"page", name:"Torn Page", x: 420, y: 620 },
        { id:"page2", type:"page", name:"Torn Page", x: 1920, y: 420 },
        { id:"page3", type:"page", name:"Torn Page", x: 1280, y: 1500 },
        { id:"noteA", type:"note", name:"Crumpled Note", x: 860, y: 980, text:"If you sprint… it hears you." },
        { id:"batteryA", type:"battery", name:"Battery", x: 2100, y: 820, amount: 35 },
        { id:"medA", type:"medkit", name:"Medkit", x: 520, y: 1520 }
      ],
      hideSpots:[
        { id:"bush1", name:"Dense Bush", x: 1480, y: 520, w: 120, h: 90 },
        { id:"bush2", name:"Hollow Tree", x: 900, y: 1400, w: 120, h: 90 }
      ],
      triggers:[
        { id:"fogWhisper", once:true, rect:{x:980,y:740,w:260,h:220}, action:"WHISPER" },
        { id:"snapBranch", once:true, rect:{x:1560,y:1040,w:240,h:240}, action:"BRANCH_SNAP" }
      ]
    },
    {
      id:"house",
      name:"ABANDONED HOUSE",
      size:{ w:2200, h:1600 },
      fog: 0.85,
      ambience: { drone: true, spookChance: 0.00035 },
      playerSpawn:{ x: 2000, y: 1400 },
      enemySpawn:{ x: 420, y: 320 },
      quests:[
        { id:"find_key", title:"FIND THE KEY", desc:"Find the Rusty Key.", status:"active" },
        { id:"unlock_door", title:"UNLOCK THE EXIT", desc:"Use the key to unlock the exit door.", status:"locked" },
        { id:"escape", title:"ESCAPE", thTitle:"หนีออกไป", desc:"Reach the exit.", thDesc:"ไปให้ถึงทางออก", status:"locked" }
      ],
      walls:[
        {x:-100,y:-100,w:2400,h:100},{x:-100,y:1600,w:2400,h:100},{x:-100,y:0,w:100,h:1600},{x:2200,y:0,w:100,h:1600},
        // house rooms
        {x:260,y:220,w:1400,h:60},{x:260,y:220,w:60,h:980},{x:260,y:1140,w:1400,h:60},{x:1600,y:220,w:60,h:980},
        // interior walls
        {x:620,y:220,w:60,h:560},{x:980,y:580,w:60,h:560},
        {x:260,y:520,w:520,h:60},{x:1180,y:520,w:480,h:60},
        {x:260,y:880,w:520,h:60},{x:1180,y:880,w:480,h:60},
      ],
      doors:[
        { id:"exitDoor", x: 160, y: 140, w: 90, h: 22, type:"exit", locked:true, keyId:"rusty_key" }
      ],
      exit:{ x: 130, y: 130, r: 70, doorId:"exitDoor" },
      items:[
        { id:"key1", type:"key", keyId:"rusty_key", name:"Rusty Key", x: 420, y: 300 },
        { id:"batteryB", type:"battery", name:"Battery", x: 1500, y: 980, amount: 30 },
        { id:"medB", type:"medkit", name:"Medkit", x: 520, y: 1040 },
        { id:"noteB", type:"note", name:"Diary", x: 1100, y: 320, text:"The lock is old… but it still holds." },
      ],
      hideSpots:[
        { id:"closet", name:"Closet", x: 1480, y: 260, w: 110, h: 90 },
        { id:"bed", name:"Under Bed", x: 420, y: 980, w: 120, h: 90 },
      ],
      triggers:[
        { id:"doorSlam", once:true, rect:{x:980,y:260,w:260,h:220}, action:"DOOR_SLAM" },
        { id:"breath", once:true, rect:{x:520,y:520,w:260,h:220}, action:"BREATH" }
      ]
    },
    {
      id:"library",
      name:"HAUNTED LIBRARY",
      nameTH:"ห้องสมุดหลอน",
      size:{ w:2400, h:1800 },
      fog: 0.95,
      ambience: { drone: true, spookChance: 0.00045 },
      playerSpawn:{ x: 2100, y: 1600 },
      enemySpawn:{ x: 420, y: 320 },
      quests:[
        { id:"find_code", title:"FIND THE CODE", thTitle:"หาโค้ดประตู", desc:"Find the note that contains the door code.", thDesc:"หากระดาษโน้ตที่มีรหัสประตู", status:"active" },
        { id:"unlock", title:"UNLOCK THE DOOR", thTitle:"ปลดล็อกประตู", desc:"Enter the 4-digit code.", thDesc:"ป้อนรหัส 4 หลัก", status:"locked" },
        { id:"escape", title:"ESCAPE", thTitle:"หนีออกไป", desc:"Reach the exit.", thDesc:"ไปให้ถึงทางออก", status:"locked" }
      ],
      walls:[
        {x:-100,y:-100,w:2600,h:100},{x:-100,y:1800,w:2600,h:100},{x:-100,y:0,w:100,h:1800},{x:2400,y:0,w:100,h:1800},
        // shelves blocks
        {x:300,y:260,w:60,h:1100, kind:"shelf"},{x:520,y:260,w:60,h:1100, kind:"shelf"},{x:740,y:260,w:60,h:1100, kind:"shelf"},
        {x:1200,y:260,w:60,h:1100, kind:"shelf"},{x:1420,y:260,w:60,h:1100, kind:"shelf"},{x:1640,y:260,w:60,h:1100, kind:"shelf"},
        {x:300,y:260,w:1600,h:60, kind:"shelf"},{x:300,y:1300,w:1600,h:60, kind:"shelf"},
        {x:980,y:620,w:420,h:60, kind:"shelf"},{x:980,y:980,w:420,h:60, kind:"shelf"},
      ],
      doors:[
        { id:"codeDoor", x: 160, y: 140, w: 90, h: 22, type:"exit", locked:true, code:"1937", unlocked:false }
      ],
      exit:{ x: 130, y: 130, r: 70, doorId:"codeDoor" },
      items:[
        { id:"noteCode", type:"note", name:"Torn Diary", x: 1080, y: 860, text:"Door code = 1937" , givesCodeFor:"codeDoor" },
        { id:"batteryC", type:"battery", name:"Battery", x: 2000, y: 720, amount: 35 },
        { id:"medC", type:"medkit", name:"Medkit", x: 560, y: 1520 },
        { id:"talisman", type:"talisman", name:"Talisman", x: 1580, y: 520 }
      ],
      hideSpots:[
        { id:"desk", name:"Under Desk", x: 980, y: 520, w: 130, h: 90 },
        { id:"cab", name:"Cabinet", x: 1780, y: 340, w: 110, h: 90 },
      ],
      triggers:[
        { id:"bookFall", once:true, rect:{x:980,y:520,w:260,h:220}, action:"BOOK_FALL" },
        { id:"whisper2", once:true, rect:{x:1560,y:980,w:260,h:220}, action:"WHISPER" }
      ]
    }
  ],
  def(){ return this.defs[this.idx]; },
  name(){
    const d=this.def();
    if(curLang()==="th" && d.nameTH) return d.nameTH;
    return d.name;
  },
  load(idx, isFromSave=false){
    this.idx = clamp(idx, 0, this.defs.length-1);
    const def=this.def();

    // apply fog default for chapter to settings (preview only)
    Game.chapterFogBase = def.fog;

    World.build(def, isFromSave);
    Quest.resetForChapter(def.id);

    if(!isFromSave){
      Player.spawn(def.playerSpawn.x, def.playerSpawn.y);
      Enemy.spawn(def.enemySpawn.x, def.enemySpawn.y);
      Game.resetAmbient(def);
      Inventory.reset();
      Journal.reset();
      Flashlight.reset();
      Focus.reset();
      Stats.reset();

      Save.autosave("new_chapter");
    }

    UI.refreshAll();
  },
  unlockNext(){
    const prog=Save.getProgress();
    const next = this.idx + 1;
    if(next < this.defs.length){
      if(!prog.unlocked.includes(next)) prog.unlocked.push(next);
      prog.lastChapter = next;
      Save.setProgress(prog);
    }
  }
};

const World={
  size:{w:2400,h:1800},
  walls:[], doors:[], items:[], hide:[], triggers:[],
  exit:{x:130,y:130,r:70,doorId:null},

  build(def, keepState){
    this.size = { ...def.size };
    this.walls = def.walls.map(w=>({ ...w }));
    this.doors = def.doors.map(d=>({ ...d, open:false, unlocked:!!d.unlocked }));
    this.items = def.items.map(it=>({ ...it, collected:false }));
    this.hide = def.hideSpots.map(h=>({ ...h }));
    this.triggers = def.triggers.map(t=>({ ...t, fired:false }));

    this.exit = { ...def.exit };

    // if keepState true, state will be applied later by World.apply
  },

  doorById(id){ return this.doors.find(d=>d.id===id); },
  itemById(id){ return this.items.find(i=>i.id===id); },

  inInteractRange(obj, px, py){
    if(obj.kind==="door"){
      const cx=obj.x+obj.w/2, cy=obj.y+obj.h/2;
      return dist(cx,cy,px,py) < 90;
    }
    if(obj.kind==="hide"){
      const cx=obj.x+obj.w/2, cy=obj.y+obj.h/2;
      return dist(cx,cy,px,py) < 80;
    }
    if(obj.kind==="item"){
      return dist(obj.x,obj.y,px,py) < 75;
    }
    return false;
  },

  getNearestInteractable(px, py){
    let best=null, bd=Infinity;

    // items
    for(const it of this.items){
      if(it.collected) continue;
      const d=dist(it.x,it.y,px,py);
      if(d<75 && d<bd){ bd=d; best={ kind:"item", ref:it, x:it.x, y:it.y, name: it.name }; }
    }

    // hide spots
    for(const h of this.hide){
      const cx=h.x+h.w/2, cy=h.y+h.h/2;
      const d=dist(cx,cy,px,py);
      if(d<80 && d<bd){ bd=d; best={ kind:"hide", ref:h, x:h.x, y:h.y, w:h.w, h:h.h, name: h.name }; }
    }

    // doors
    for(const d0 of this.doors){
      if(d0.open) continue;
      const cx=d0.x+d0.w/2, cy=d0.y+d0.h/2;
      const d=dist(cx,cy,px,py);
      if(d<90 && d<bd){ bd=d; best={ kind:"door", ref:d0, x:d0.x, y:d0.y, w:d0.w, h:d0.h, name: d0.id }; }
    }

    return best;
  },

  collideRect(x,y,w,h){
    // bounds
    if(x<0 || y<0 || x+w>this.size.w || y+h>this.size.h) return true;

    for(const wall of this.walls){
      if(x < wall.x+wall.w && x+w > wall.x && y < wall.y+wall.h && y+h > wall.y) return true;
    }
    for(const d of this.doors){
      if(d.open) continue;
      if(x < d.x+d.w && x+w > d.x && y < d.y+d.h && y+h > d.y) return true;
    }
    return false;
  },

  lineOfSight(ax,ay,bx,by,step=18){
    const dx=bx-ax, dy=by-ay;
    const L=Math.hypot(dx,dy);
    if(L<1) return true;
    const n=Math.ceil(L/step);
    for(let i=1;i<=n;i++){
      const t=i/n;
      const x=ax+dx*t, y=ay+dy*t;
      // check point inside any wall/closed door
      for(const w of this.walls){
        if(x>=w.x && y>=w.y && x<=w.x+w.w && y<=w.y+w.h) return false;
      }
      for(const d of this.doors){
        if(d.open) continue;
        if(x>=d.x && y>=d.y && x<=d.x+d.w && y<=d.y+d.h) return false;
      }
    }
    return true;
  },

  isAtExit(px,py){
    return dist(px,py,this.exit.x,this.exit.y) < this.exit.r;
  },

  pack(){
    return {
      items: this.items.map(i=>({ id:i.id, collected:!!i.collected })),
      doors: this.doors.map(d=>({ id:d.id, open:!!d.open, unlocked:!!d.unlocked })),
      triggers: this.triggers.map(t=>({ id:t.id, fired:!!t.fired }))
    };
  },
  apply(d){
    const itemMap = new Map((d.items||[]).map(x=>[x.id,x]));
    for(const it of this.items){
      const s=itemMap.get(it.id);
      if(s) it.collected=!!s.collected;
    }
    const doorMap = new Map((d.doors||[]).map(x=>[x.id,x]));
    for(const dr of this.doors){
      const s=doorMap.get(dr.id);
      if(s){ dr.open=!!s.open; dr.unlocked=!!s.unlocked; }
    }
    const trigMap = new Map((d.triggers||[]).map(x=>[x.id,x]));
    for(const t of this.triggers){
      const s=trigMap.get(t.id);
      if(s) t.fired=!!s.fired;
    }
  }
};

/* ===================== PLAYER ===================== */
const Player={
  x:100, y:1000,
  vx:0, vy:0,
  w:20, h:20,
  stamina:100,
  fear:0,
  speed:140,
  sprintMult:1.85,
  accel:2200,
  friction:12,
  dirAngle:0,
  hidden:false,
  hideSpotId:null,
  stepTimer:0,
  noise:0,
  walk:0, // walk animation phase
  idleT:0, // idle/breathing timer
  // current perceived noise level 0..100

  spawn(x,y){ this.x=x; this.y=y; this.vx=0; this.vy=0; this.hidden=false; this.hideSpotId=null; },

  pack(){
    return {
      x:this.x,y:this.y,vx:this.vx,vy:this.vy,
      stamina:this.stamina,fear:this.fear,
      hidden:this.hidden, hideSpotId:this.hideSpotId,
      flashlight:{ on:Flashlight.on, battery:Flashlight.battery },
      focus:{ val:Focus.val, cooldown:Focus.cooldown }
    };
  },
  apply(d){
    this.x=d.x??this.x; this.y=d.y??this.y;
    this.vx=d.vx??0; this.vy=d.vy??0;
    this.stamina=d.stamina??100;
    this.fear=d.fear??0;
    this.hidden=!!d.hidden;
    this.hideSpotId=d.hideSpotId??null;

    if(d.flashlight){ Flashlight.on=!!d.flashlight.on; Flashlight.battery=d.flashlight.battery??100; }
    if(d.focus){ Focus.val=d.focus.val??100; Focus.cooldown=d.focus.cooldown??0; }
  },

  setHidden(on, spotId=null){
    this.hidden=on;
    this.hideSpotId=on ? spotId : null;
    if(on){
      Journal.add(`Hiding… hold your breath.`);
      AudioSys.ensure(); AudioSys.tone(160,"sine",0.14,0.08);
    }else{
      Journal.add(`Left hiding spot.`);
      AudioSys.ensure(); AudioSys.tone(420,"sine",0.06,0.08);
    }
  },

  update(dt){
    if(this.hidden){
      this.idleT += dt;
      // still gain fear slowly if enemy is close
      const d=dist(this.x,this.y,Enemy.x,Enemy.y);
      if(d<160) this.fear = clamp(this.fear + 15*dt, 0, 100);
      // medkit quick-use via I drawer? (we keep use in UI)
      this.noise = 0;
      this.vx=0; this.vy=0;
      return;
    }

    // movement
    let dx=0,dy=0;
    if(Input.k["KeyW"]) dy=-1;
    if(Input.k["KeyS"]) dy=1;
    if(Input.k["KeyA"]) dx=-1;
    if(Input.k["KeyD"]) dx=1;

    if(dx!==0 || dy!==0){
      const L=Math.hypot(dx,dy);
      dx/=L; dy/=L;
      this.dirAngle = Math.atan2(dy,dx);
    }

    const sprint = Input.k["ShiftLeft"] && this.stamina>0 && (dx||dy);
    this.isSprinting = !!sprint;
    let maxSpd=this.speed*(sprint?this.sprintMult:1);

    if(sprint){
      this.stamina = Math.max(0, this.stamina - 30*dt);
    }else{
      this.stamina = Math.min(100, this.stamina + 10*dt);
    }

    // accel
    if(dx||dy){
      this.vx += dx*this.accel*dt;
      this.vy += dy*this.accel*dt;

      // footsteps + noise events
      this.stepTimer += dt;
      const stepFreq = sprint ? 0.25 : 0.42;
      if(this.stepTimer >= stepFreq){
        this.stepTimer = 0;
        Stats.steps++;
        AudioSys.ensure();
        AudioSys.noise(0.06, sprint?0.12:0.07, sprint?520:380);

        const baseNoise = sprint ? 70 : 35;
        NoiseSystem.emit(this.x,this.y, baseNoise, sprint?520:360, "step");
      }
    }else{
      this.stepTimer=0;
    }


    // animation phase
    this.idleT += dt;
    const moving = !!(dx||dy);
    if(moving){
      // keep walk phase running; faster when sprinting
      this.walk += dt * (sprint ? 14.0 : 9.0);
    }else{
      // ease walk swing down when idle (keep it near 0 for stable pose)
      this.walk = this.walk * 0.85;
    }

    // friction
    this.vx -= this.vx*this.friction*dt;
    this.vy -= this.vy*this.friction*dt;

    const sp=Math.hypot(this.vx,this.vy);
    if(sp>maxSpd){
      const s=maxSpd/sp;
      this.vx*=s; this.vy*=s;
    }

    // fear decay slow
    if(this.fear>0) this.fear = Math.max(0, this.fear - 5*dt);

    // move with collision
    this.tryMove(this.vx*dt,0);
    this.tryMove(0,this.vy*dt);
  },

  tryMove(dx,dy){
    const nx=this.x+dx, ny=this.y+dy;
    if(!World.collideRect(nx-this.w/2, this.y-this.h/2, this.w, this.h)) this.x=nx;
    else this.vx=0;

    if(!World.collideRect(this.x-this.w/2, ny-this.h/2, this.w, this.h)) this.y=ny;
    else this.vy=0;
  }
};

/* ===================== NOISE SYSTEM ===================== */
const NoiseSystem={
  events:[],
  emit(x,y,strength=50,radius=400, tag="generic"){
    this.events.push({ x,y, strength, radius, tag, life: 0.8 });
  },
  update(dt){
    for(const e of this.events) e.life -= dt;
    this.events = this.events.filter(e=>e.life>0);
  },
  calcPlayerNoise(){
    // for HUD info only
    let n=0;
    const speed=Math.hypot(Player.vx,Player.vy);
    n += clamp(speed/220*40, 0, 40);
    if(Input.k["ShiftLeft"] && speed>5) n += 35;
    if(InteractHold.holding) n += 10;
    if(Player.hidden) n *= 0.2;
    Player.noise = clamp(n,0,100);
  }
};

/* ===================== ENEMY AI ===================== */
const Enemy={
  x:420,y:320,
  vx:0,vy:0,
  w:26,h:26,
  state:"PATROL", // PATROL / INVESTIGATE / CHASE / SEARCH
  target:{x:0,y:0},
  seenTimer:0,
  loseTimer:0,
  patrolPts:[],
  patrolIdx:0,
  detection:0, // 0..100
  hearing:1.0,
  speed:120,
  viewDist: 420,
  attackDist: 26,
  lastHeard:null,

  spawn(x,y){
    this.x=x; this.y=y;
    this.vx=0; this.vy=0;
    this.state="PATROL";
    this.detection=0;
    this.seenTimer=0;
    this.loseTimer=0;
    this.lastHeard=null;

    // patrol points simple ring
    this.patrolPts = [
      {x:x,y:y},
      {x: x+420, y: y+120},
      {x: x+240, y: y+420},
      {x: x-120, y: y+260},
    ];
    this.patrolIdx=0;
    this.target={...this.patrolPts[0]};
  },

  difficultyScale(){
    const d=Settings.data.game.difficulty;
    if(d==="easy") return { hearing:0.80, speed:0.92, view:0.90, det:0.85 };
    if(d==="hard") return { hearing:1.18, speed:1.08, view:1.05, det:1.18 };
    return { hearing:1.00, speed:1.00, view:1.00, det:1.00 };
  },

  pack(){
    return {
      x:this.x,y:this.y,state:this.state,
      target:this.target, patrolIdx:this.patrolIdx,
      detection:this.detection, seenTimer:this.seenTimer, loseTimer:this.loseTimer,
      lastHeard:this.lastHeard
    };
  },
  apply(d){
    this.x=d.x??this.x; this.y=d.y??this.y;
    this.state=d.state??this.state;
    this.target=d.target??this.target;
    this.patrolIdx=d.patrolIdx??this.patrolIdx;
    this.detection=d.detection??this.detection;
    this.seenTimer=d.seenTimer??0;
    this.loseTimer=d.loseTimer??0;
    this.lastHeard=d.lastHeard??null;

    // rebuild patrol ring around current pos if not exist
    if(!Array.isArray(this.patrolPts) || !this.patrolPts.length) this.spawn(this.x,this.y);
  },

  update(dt){
    const sc=this.difficultyScale();
    this.hearing=sc.hearing;
    this.speed=120*sc.speed;
    const view=this.viewDist*sc.view;

    // hearing: listen to latest noise events
    let best=null, bd=Infinity;
    for(const n of NoiseSystem.events){
      const d=dist(this.x,this.y,n.x,n.y);
      const eff = n.radius * this.hearing;
      if(d <= eff){
        // choose strongest/closest
        const score = d / Math.max(1,(n.strength/50));
        if(score < bd){ bd=score; best=n; }
      }
    }
    if(best){
      this.lastHeard = { x: best.x, y: best.y, tag: best.tag, ts: now() };
      if(this.state!=="CHASE"){
        this.state="INVESTIGATE";
        this.target={ x: best.x, y: best.y };
      }
    }

    // vision (line of sight)
    const pVis = this.canSeePlayer(view);
    if(pVis){
      this.seenTimer += dt;
      this.loseTimer = 0;
      // detection builds faster if flashlight is ON (you give away position)
      let detRate = (Player.hidden ? 3 : 26) * sc.det;
      if(Flashlight.on && Flashlight.battery>0) detRate *= 1.22;
      if(Input.k["ShiftLeft"]) detRate *= 1.12;
      this.detection = clamp(this.detection + detRate*dt, 0, 100);
    }else{
      this.loseTimer += dt;
      this.seenTimer = 0;
      this.detection = clamp(this.detection - 12*dt, 0, 100);
    }

    // state transitions
    if(this.detection >= 55 && !Player.hidden){
      this.state="CHASE";
      this.target={ x: Player.x, y: Player.y };
    }

    if(this.state==="CHASE"){
      // if lost long enough -> SEARCH at last known / last heard
      if(!pVis && this.loseTimer > 2.4){
        this.state="SEARCH";
        const lk = this.lastHeard ? {x:this.lastHeard.x,y:this.lastHeard.y} : {x:Player.x,y:Player.y};
        this.target = lk;
      }else{
        this.target={ x: Player.x, y: Player.y };
      }
    }

    if(this.state==="INVESTIGATE"){
      if(dist(this.x,this.y,this.target.x,this.target.y)<40){
        this.state="SEARCH";
      }
      if(this.detection>45 && !Player.hidden) this.state="CHASE";
    }

    if(this.state==="SEARCH"){
      // wander around target
      if(dist(this.x,this.y,this.target.x,this.target.y)<60){
        if(Math.random()<0.02){
          this.target = {
            x: clamp(this.target.x + rand(-220,220), 120, World.size.w-120),
            y: clamp(this.target.y + rand(-220,220), 120, World.size.h-120)
          };
        }
      }
      if(this.detection<12 && this.loseTimer>4){
        this.state="PATROL";
        this.target={...this.patrolPts[this.patrolIdx]};
      }
      if(pVis && !Player.hidden) this.state="CHASE";
    }

    if(this.state==="PATROL"){
      const pt=this.patrolPts[this.patrolIdx];
      this.target={...pt};
      if(dist(this.x,this.y,pt.x,pt.y)<45){
        this.patrolIdx=(this.patrolIdx+1)%this.patrolPts.length;
      }
      if(this.detection>45 && !Player.hidden) this.state="CHASE";
    }

    // movement steering + simple collision avoid
    this.moveToTarget(dt);

    // attack
    const dToP=dist(this.x,this.y,Player.x,Player.y);
    if(dToP < this.attackDist && !Player.hidden){
      this.attack();
    }

    // induce fear by proximity even if hidden (less)
    const prox = clamp(1 - (dToP-60)/520, 0, 1);
    const fearGain = (Player.hidden ? 14 : 24) * prox;
    Player.fear = clamp(Player.fear + fearGain*dt, 0, 100);
  },

  canSeePlayer(viewDist){
    if(Player.hidden) return false; // hiding blocks vision by design
    const d=dist(this.x,this.y,Player.x,Player.y);
    if(d>viewDist) return false;
    // line of sight
    return World.lineOfSight(this.x,this.y,Player.x,Player.y,18);
  },

  moveToTarget(dt){
    const tx=this.target.x, ty=this.target.y;
    let dx=tx-this.x, dy=ty-this.y;
    const L=Math.hypot(dx,dy);
    if(L<1) return;
    dx/=L; dy/=L;

    // state speed factor
    let sp=this.speed;
    if(this.state==="PATROL") sp*=0.75;
    if(this.state==="SEARCH") sp*=0.85;
    if(this.state==="CHASE") sp*=1.10;

    const vx=dx*sp*dt;
    const vy=dy*sp*dt;

    this.tryMove(vx,0);
    this.tryMove(0,vy);

    // small jitter when close (creepy)
    if(this.state==="CHASE" && Math.random()<0.04){
      this.x += rand(-1,1);
      this.y += rand(-1,1);
    }
  },

  tryMove(dx,dy){
    const nx=this.x+dx, ny=this.y+dy;
    if(!World.collideRect(nx-this.w/2, this.y-this.h/2, this.w, this.h)) this.x=nx;
    else { /* slide */ }

    if(!World.collideRect(this.x-this.w/2, ny-this.h/2, this.w, this.h)) this.y=ny;
    else { /* slide */ }
  },

  attack(){
    Stats.deaths++;
    Stats.scares++;
    AudioSys.ensure();
    AudioSys.tone(95,"sawtooth",0.22,0.55);
    UI.flashPanic();

    // penalty
    Player.stamina=0;
    Player.fear=100;
    Game.shake = 24;

    // reset positions but keep chapter
    const def=Chapter.def();
    Player.spawn(def.playerSpawn.x, def.playerSpawn.y);
    this.spawn(def.enemySpawn.x, def.enemySpawn.y);

    Journal.add("It caught you… you barely escaped.");
    Save.autosave("attacked");
  }
};

/* ===================== UI ===================== */
const UI={
  debug:false,
  drawerMode:"journal",
  showMarker:true,

  applyLanguage(lang){
    const L = I18N[lang] || I18N.en;

    // Loading
    const loadingSub=document.getElementById("loadingSub");
    if(loadingSub) loadingSub.textContent = L.loading.sub;
    const tipEl=document.querySelector("#loadingBox > div:last-child");
    if(tipEl) tipEl.textContent = L.loading.tip;

    // Menu items
    const menuItems=[...document.querySelectorAll("#menuList .menuItem")];
    for(const el of menuItems){
      const act=el.getAttribute("data-action");
      const m=L.menu[act];
      if(!m) continue;
      el.textContent = m.label;
      el.dataset.title = m.label;
      el.dataset.desc = m.desc;
    }

    // Menu description box refresh
    const active=document.querySelector("#menuList .menuItem.active");
    if(active){
      const mt=document.getElementById("menuDescTitle");
      const ms=document.getElementById("menuDescSub");
      if(mt) mt.textContent = active.dataset.title || active.textContent;
      if(ms) ms.textContent = active.dataset.desc || "";
    }

    // Hint bar
    const hintTexts=[...document.querySelectorAll("#hintBar .hintText")];
    const hintKeys=["move","sprint","hold","light","calm","journal","inventory","pause"];
    hintTexts.forEach((el,i)=>{ const k=hintKeys[i]; if(k && L.hint[k]) el.textContent=L.hint[k]; });

    // HUD titles
    const hudTitles=[...document.querySelectorAll("#hud .hudTitle")];
    if(hudTitles[0]) hudTitles[0].textContent=L.hud.stamina;
    if(hudTitles[1]) hudTitles[1].textContent=L.hud.battery;

    // Settings label for language (optional)
    const langName=document.querySelector('#tab-game .name');
    const langHint=document.querySelector('#tab-game .hint');
    // Not forcing; these elements may not map 1:1, keep safe.

    // Update objective immediately
    this.updateObjective?.();
  },

  showScreen(which){
    // hide all modal screens
    ["screenLoading","screenPause","screenSettings","screenSave","screenChapter","screenCode","screenComplete"].forEach(id=>{
      document.getElementById(id).classList.remove("active");
    });
    document.getElementById("menu").classList.remove("active");

    if(which==="menu"){
      document.getElementById("menu").classList.add("active");
      Game.state="MENU";
      this.setHudVisible(false);
      return;
    }
    if(which==="loading"){
      document.getElementById("screenLoading").classList.add("active");
      Game.state="LOADING";
      this.setHudVisible(false);
      return;
    }
    if(which==="pause"){
      document.getElementById("screenPause").classList.add("active");
      this.setHudVisible(true);
      return;
    }
    if(which==="settings"){
      document.getElementById("screenSettings").classList.add("active");
      this.setHudVisible(false);
      Settings.open();
      return;
    }
    if(which==="save"){
      document.getElementById("screenSave").classList.add("active");
      this.setHudVisible(false);
      SaveUI.render();
      return;
    }
    if(which==="chapter"){
      document.getElementById("screenChapter").classList.add("active");
      this.setHudVisible(false);
      ChapterUI.render();
      return;
    }
    if(which==="code"){
      document.getElementById("screenCode").classList.add("active");
      this.setHudVisible(true);
      return;
    }
    if(which==="complete"){
      document.getElementById("screenComplete").classList.add("active");
      this.setHudVisible(false);
      return;
    }
  },

  setHudVisible(v){
    document.getElementById("hud").classList.toggle("visible", !!v);
  },

  setInteract(show, text){
    const el=document.getElementById("interact");
    el.style.opacity = show ? 1 : 0;
    if(text) document.getElementById("interactTxt").textContent = text;
  },
  setHold(p){
    document.getElementById("ring").style.setProperty("--p", String(clamp(p,0,1)));
  },

  toggleDrawer(mode){
    if(Game.state!=="PLAY" && Game.state!=="PAUSE") return;
    const d=document.getElementById("drawer");
    const open=d.classList.toggle("open");
    if(open){
      this.drawerMode = mode || this.drawerMode;
      if(mode==="inventory") document.getElementById("drawerTitle").textContent="INVENTORY";
      else document.getElementById("drawerTitle").textContent="JOURNAL";
      this.refreshDrawer();
    }
  },

  refreshDrawer(){
    document.getElementById("questBox").innerHTML = Quest.activeText();
    document.getElementById("invBox").innerHTML = Inventory.listText() + `<div style="margin-top:10px;">
      <button class="ghost" style="width:100%;" onclick="Inventory.useMedkit()">USE MEDKIT</button>
    </div>`;
    document.getElementById("notesBox").innerHTML = Journal.listText();
  },

  refreshInvMini(){
    const keys=Object.keys(Inventory.items);
    if(!keys.length){ document.getElementById("invMini").textContent="—"; return; }
    const short = keys.slice(0,4).map(k=>`${k.toUpperCase()}x${Inventory.items[k]}`).join(" • ");
    document.getElementById("invMini").textContent = short + (keys.length>4 ? " • …" : "");
  },

  updateBars(){
    document.getElementById("staminaFill").style.width = `${clamp(Player.stamina,0,100)}%`;
    document.getElementById("fearFill").style.width = `${clamp(Player.fear,0,100)}%`;

    const b = clamp(Flashlight.battery,0,100);
    const bf = document.getElementById("batteryFill");
    bf.style.width = `${b}%`;
    bf.classList.toggle("low", b>0 && b<=Flashlight.lowAt);
    bf.classList.toggle("crit", b>0 && b<=Flashlight.critAt);
    bf.classList.toggle("off", !Flashlight.on);

    document.getElementById("focusFill").style.width = `${clamp(Focus.val,0,100)}%`;

    const tf=document.getElementById("tensionFill");
    if(tf){ tf.style.width = `${Math.round(clamp(Game.tension,0,1)*100)}%`; }
  },

  updateObjective(){
    document.getElementById("objectiveTxt").textContent = Quest.objectiveText();
    const L = I18N[curLang()] || I18N.en;
    document.getElementById("miniInfo").textContent = `${(L.misc?.chapterPrefix||"CHAPTER")}: ${Chapter.name()} • ${(L.misc?.noisePrefix||"NOISE")}: ${Math.round(Player.noise)}`;
  },

  marker(wx,wy,label){
    const el=document.getElementById("marker");
    if(!this.showMarker || Game.state!=="PLAY"){ el.classList.remove("show"); return; }

    const s=(Game.canvas.width/window.innerWidth)||1;
    const sx=(wx-Game.cam.x)/s;
    const sy=(wy-Game.cam.y)/s;

    const cx=window.innerWidth/2, cy=window.innerHeight/2;
    const dx=sx-cx, dy=sy-cy;

    const pad=80;
    const maxX=(window.innerWidth/2)-pad;
    const maxY=(window.innerHeight/2)-pad;
    const k=Math.min(1, Math.min(maxX/Math.max(1,Math.abs(dx)), maxY/Math.max(1,Math.abs(dy))));

    const px=cx+dx*k, py=cy+dy*k;

    el.style.left=px+"px";
    el.style.top=py+"px";
    el.classList.add("show");

    const ang=Math.atan2(dy,dx)*180/Math.PI+90;
    document.getElementById("arrow").style.transform = `rotate(${ang}deg)`;
    document.getElementById("markerLabel").textContent = label||"OBJECTIVE";
  },

  flashPanic(){
    const reduce=Settings.data.game.reduceFlashes;
    const p=document.getElementById("panic");
    p.style.opacity = reduce ? 0.22 : 0.85;
    setTimeout(()=>p.style.opacity=0, reduce ? 120 : 220);
  },

  showGhost(ms=380){
    const reduce=Settings.data.game.reduceFlashes;
    const el=document.getElementById("ghostJumpscare");
    if(!el) return;
    // respect reduce flashes: still show but shorter and less intense
    const dur = reduce ? Math.min(260, ms) : ms;
    el.classList.remove("on");
    // restart animation
    void el.offsetWidth;
    el.classList.add("on");
    clearTimeout(this._ghostT);
    this._ghostT = setTimeout(()=> el.classList.remove("on"), dur);
  },


  refreshAll(){
    this.refreshInvMini();
    this.refreshDrawer();
    this.updateBars();
    this.updateObjective();
  }
};

/* ===================== MENU UI ===================== */
const MenuUI={
  idx:0, items:[],
  init(){
    this.items=[...document.querySelectorAll(".menuItem")].filter(el=>el.offsetParent!==null);
    if(Save.hasAny()) document.getElementById("btnContinue").style.display="block";

    this.items=[...document.querySelectorAll(".menuItem")].filter(el=>el.offsetParent!==null);

    this.items.forEach((it,i)=>{
      it.addEventListener("mouseenter",()=>this.set(i));
      it.addEventListener("click",()=>this.activate(i));
    });

    window.addEventListener("keydown",(e)=>{
      if(Game.state!=="MENU") return;
      if(e.code==="ArrowDown" || e.code==="KeyS"){ e.preventDefault(); this.move(1); }
      if(e.code==="ArrowUp" || e.code==="KeyW"){ e.preventDefault(); this.move(-1); }
      if(e.code==="Enter" || e.code==="Space"){ e.preventDefault(); this.activate(this.idx); }
    },{passive:false});

    this.set(0);
  },
  set(i){
    this.items[this.idx]?.classList.remove("active");
    this.idx=i;
    this.items[this.idx]?.classList.add("active");
    const el=this.items[this.idx];
    document.getElementById("menuDescTitle").textContent = el.dataset.title || el.textContent.trim();
    document.getElementById("menuDescSub").textContent = el.dataset.desc || "";
  },
  move(dir){
    if(!this.items.length) return;
    const n=this.items.length;
    this.set((this.idx+dir+n)%n);
  },
  activate(i){
    const action=this.items[i]?.dataset.action;
    if(!action) return;

    if(action==="new") Game.newGame();
    if(action==="continue"){
      const slot=Save.latest();
      if(slot==null) return;
      Game.loadGame(slot);
    }
    if(action==="settings") UI.showScreen("settings");
    if(action==="save") UI.showScreen("save");
    if(action==="chapter") UI.showScreen("chapter");
    if(action==="exit") location.reload();
  }
};

/* ===================== SAVE UI ===================== */
const SaveUI={
  render(){
    const root=document.getElementById("slots");
    const metaFrom=(d)=>{
      if(!d) return "EMPTY";
      const ts=d.ts ? new Date(d.ts).toLocaleString() : "Unknown";
      const pt = d.stats?.playTime!=null ? `${Math.floor(d.stats.playTime/60)}m` : "-";
      return `Last: ${ts}<br>Playtime: ${pt}<br>Chapter: ${Chapter.defs[d.chapter]?.name || d.chapter}`;
    };

    const s1=Save.loadSlot(1);
    const s2=Save.loadSlot(2);
    const s3=Save.loadSlot(3);
    const au=Save.loadAutosave();

    root.innerHTML = `
      ${this.card("SLOT 1", metaFrom(s1), 1)}
      ${this.card("SLOT 2", metaFrom(s2), 2)}
      ${this.card("SLOT 3", metaFrom(s3), 3)}
      ${this.card("AUTOSAVE", metaFrom(au), 0, true)}
    `;

    root.querySelectorAll("[data-save]").forEach(btn=>{
      btn.addEventListener("click",()=>{
        const slot=Number(btn.dataset.save);
        Save.saveSlot(slot);
        Save.autosave("manual_save");
        AudioSys.ensure(); AudioSys.tone(880,"square",0.06,0.10);
        this.render();
      });
    });

    root.querySelectorAll("[data-load]").forEach(btn=>{
      btn.addEventListener("click",()=>{
        const slot=Number(btn.dataset.load);
        Game.loadGame(slot);
      });
    });
  },
  card(title, meta, slot, isAuto=false){
    return `
      <div class="slot">
        <div class="slotTitle">${title}</div>
        <div class="slotMeta">${meta}</div>
        <div class="slotActions">
          ${isAuto? "" : `<button class="ghost" data-save="${slot}" type="button">SAVE</button>`}
          <button data-load="${slot}" type="button">LOAD</button>
        </div>
      </div>
    `;
  }
};

/* ===================== CHAPTER SELECT UI ===================== */
const ChapterUI={
  render(){
    const prog=Save.getProgress();
    const wrap=document.getElementById("chapList");
    document.getElementById("chapSub").textContent = `unlocked: ${prog.unlocked.length}/${Chapter.defs.length}`;

    wrap.innerHTML="";
    Chapter.defs.forEach((d,i)=>{
      const unlocked = prog.unlocked.includes(i);
      const btn=document.createElement("button");
      btn.textContent = `${i+1}. ${d.name}`;
      btn.disabled = !unlocked;
      btn.style.minWidth="260px";
      btn.addEventListener("click",()=>{
        Game.startChapter(i);
      });
      wrap.appendChild(btn);
    });
  }
};

/* ===================== CODE LOCK UI ===================== */
const CodeLock={
  door:null,
  open(door){
    this.door=door;
    Game.setPause(true);
    UI.showScreen("code");
    document.getElementById("codeInput").value="";
    document.getElementById("codeMsg").textContent="";
    setTimeout(()=>document.getElementById("codeInput").focus(), 60);
  },
  close(){
    UI.showScreen("pause"); // return to pause overlay
  },
  submit(){
    const v=document.getElementById("codeInput").value.trim();
    const msg=document.getElementById("codeMsg");
    if(!/^\d{4}$/.test(v)){ msg.textContent="INVALID CODE"; AudioSys.ensure(); AudioSys.tone(160,"sawtooth",0.1,0.12); return; }
    if(!this.door){ msg.textContent="NO DOOR"; return; }

    if(v===this.door.code){
      this.door.unlocked=true;
      this.door.open=true;
      msg.textContent="UNLOCKED";
      AudioSys.ensure(); AudioSys.tone(660,"sine",0.12,0.14);
      Journal.add("Door unlocked.");
      Quest.set("unlock",{ status:"done" });
      Quest.set("escape",{ status:"active" });
      Save.autosave("code_unlock");
      setTimeout(()=>{ UI.showScreen("pause"); }, 250);
    }else{
      msg.textContent="WRONG";
      AudioSys.ensure(); AudioSys.tone(120,"sawtooth",0.12,0.14);
    }
  }
};

/* ===================== SPOOK TRIGGERS ===================== */
const Spook={
  run(action){
    AudioSys.ensure();
    const reduce=Settings.data.game.reduceFlashes;

    
if(action==="WHISPER"){
  AudioSys.noise(0.25,0.16,300);
  Player.fear = clamp(Player.fear + (reduce?10:18), 0, 100);
  Journal.add("You hear whispers… from nowhere.");
}
if(action==="WHISPER3D"){
  // ambient whisper around the player (no journal spam)
  const px = Player.x + rand(-220,220);
  const py = Player.y + rand(-220,220);
  AudioSys.whisperAt(px,py);
  Player.fear = clamp(Player.fear + (reduce?4:7), 0, 100);
}
if(action==="DRIP"){
  const px = Player.x + rand(-260,260);
  const py = Player.y + rand(-260,260);
  AudioSys.dripAt(px,py);
}
    if(action==="BRANCH_SNAP"){
      AudioSys.noise(0.12,0.22,450);
      Player.fear = clamp(Player.fear + (reduce?12:22), 0, 100);
      NoiseSystem.emit(Player.x+rand(-120,120), Player.y+rand(-120,120), 65, 520, "spook");
      Journal.add("A branch snaps nearby.");
    }
    if(action==="DOOR_SLAM"){
      AudioSys.noise(0.18,0.28,520);
      UI.flashPanic();
      UI.showGhost();
      Player.fear = clamp(Player.fear + (reduce?14:26), 0, 100);
      Journal.add("A door slams behind you.");
      // make enemy investigate
      NoiseSystem.emit(Player.x+rand(-160,160), Player.y+rand(-160,160), 85, 650, "slam");
    }
    if(action==="BREATH"){
      AudioSys.noise(0.22,0.18,260);
      Player.fear = clamp(Player.fear + (reduce?10:20), 0, 100);
      UI.showGhost(320);
      Journal.add("A cold breath on your neck.");
    }
    if(action==="BOOK_FALL"){
      AudioSys.noise(0.14,0.24,560);
      UI.flashPanic();
      UI.showGhost();
      Player.fear = clamp(Player.fear + (reduce?14:28), 0, 100);
      Journal.add("Books crash to the floor.");
      NoiseSystem.emit(Player.x+rand(-120,120), Player.y+rand(-120,120), 80, 620, "books");
    }
  }
};

/* ===================== GAME CORE ===================== */
const Game={
  canvas:null, ctx:null,
  state:"LOADING", // LOADING / MENU / PLAY / PAUSE
  last:0,
  cam:{x:0,y:0},
  renderScale:1.0,
  pixelate:false,
  fogMult:0.85,
  // ambient timers (drip/whisper) + tension
  amb:{ dripT:0, whisperT:0 },
  tension:0,

  chapterFogBase:0.85,
  shakeMult:1.0,
  shake:0,
  autosaveTimer:0,

  init(){
    this.canvas=document.getElementById("game");
    this.ctx=this.canvas.getContext("2d");
    this.resize();
    window.addEventListener("resize",()=>this.resize());

    Input.init();
    Settings.load();
    Settings.bindUI();

    // grain background
    const post=document.getElementById("post");
    const g=document.createElement("canvas");
    g.width=220; g.height=220;
    const gx=g.getContext("2d");
    const img=gx.createImageData(220,220);
    for(let i=0;i<img.data.length;i+=4){
      const v=Math.random()*50;
      img.data[i]=v; img.data[i+1]=v; img.data[i+2]=v;
      img.data[i+3]=Math.random()*18;
    }
    gx.putImageData(img,0,0);
    post.style.backgroundImage = `url(${g.toDataURL()})`;

    // hook UI buttons
    this.bindButtons();

    // fake loading then menu
    this.bootLoading();

    requestAnimationFrame((t)=>this.loop(t));
  },

  bindButtons(){
    document.getElementById("btnResume").addEventListener("click",()=>this.setPause(false));
    document.getElementById("btnSaveOpen").addEventListener("click",()=>UI.showScreen("save"));
    document.getElementById("btnSettingsOpen").addEventListener("click",()=>UI.showScreen("settings"));
    document.getElementById("btnToMenu").addEventListener("click",()=>UI.showScreen("menu"));

    document.getElementById("btnSaveBack").addEventListener("click",()=>{
      if(this.state==="PAUSE") UI.showScreen("pause");
      else UI.showScreen("menu");
    });
    document.getElementById("btnWipe").addEventListener("click",()=>{
      Save.wipeAll();
      UI.showScreen("save");
      if(Save.hasAny()) document.getElementById("btnContinue").style.display="block";
      else document.getElementById("btnContinue").style.display="none";
      RemoteSync.warmup();
  MenuUI.init();
    });

    document.getElementById("btnChapBack").addEventListener("click",()=>UI.showScreen("menu"));

    document.getElementById("btnCodeBack").addEventListener("click",()=>{ UI.showScreen("pause"); });
    document.getElementById("btnCodeOk").addEventListener("click",()=>CodeLock.submit());
    document.getElementById("codeInput").addEventListener("keydown",(e)=>{ if(e.code==="Enter") CodeLock.submit(); });

    document.getElementById("btnDoneMenu").addEventListener("click",()=>UI.showScreen("menu"));
    document.getElementById("btnNextChapter").addEventListener("click",()=>{
      const next = Chapter.idx + 1;
      if(next < Chapter.defs.length){
        this.startChapter(next);
      }else{
        UI.showScreen("menu");
      }
    });
  },

  bootLoading(){
    UI.showScreen("loading");
    let p=0;
    const bar=document.getElementById("barFill");
    const pct=document.getElementById("loadingPct");
    const steps=[
      "booting","initializing","decrypting records","loading chapters","preparing audio","ready"
    ];
    let si=0;
    const sub=document.getElementById("loadingSub");

    const tick=()=>{
      p = Math.min(100, p + rand(1.5,4.5));
      bar.style.width = p.toFixed(0)+"%";
      pct.textContent = `${p.toFixed(0)}%`;
      if(p> (si+1)* (100/steps.length) && si<steps.length-1){
        si++;
        sub.textContent = steps[si];
      }
      if(p>=100){
        // enter menu
        const prog=Save.getProgress();
        Chapter.load(prog.lastChapter ?? 0, false); // preload base world but not start PLAY
        UI.showScreen("menu");
        MenuUI.init();
        return;
      }
      setTimeout(tick, 45 + Math.random()*60);
    };
    setTimeout(tick, 150);

},

resetAmbient(def){
  // seed timers per chapter (avoid instant spam on load)
  this.amb.dripT = rand(5.0, 12.0);
  this.amb.whisperT = rand(8.0, 18.0);
  this.tension = 0;
  // optional drone ambience
  if(def?.ambience?.drone){
    AudioSys.ensure();
    AudioSys.startDrone();
  }else{
    if(AudioSys.drone){ try{ AudioSys.drone.stop(); }catch(e){} AudioSys.drone=null; }
  }
},

  resize(){
    const s=clamp(this.renderScale||1, 0.5, 1);
    this.canvas.width = Math.floor(window.innerWidth*s);
    this.canvas.height = Math.floor(window.innerHeight*s);
    this.canvas.style.imageRendering = this.pixelate ? "pixelated" : "auto";
  },

  newGame(){
    AudioSys.ensure(); AudioSys.startDrone();
    // reset progress (unlock chapter 1 only)
    const prog=Save.defaultProgress();
    Save.setProgress(prog);
    this.startChapter(0, true);
  },

  startChapter(idx, fresh=false){
    AudioSys.ensure(); AudioSys.startDrone();
    Chapter.load(idx, false);

    // ensure unlocked record
    const prog=Save.getProgress();
    if(!prog.unlocked.includes(idx)) prog.unlocked.push(idx);
    prog.lastChapter = idx;
    Save.setProgress(prog);

    this.state="PLAY";
    UI.setHudVisible(true);
    UI.showScreen("none"); // hide modals
    document.getElementById("menu").classList.remove("active");
    this.autosaveTimer=0;
    Save.autosave(fresh ? "new_game" : "start_chapter");
  },

  loadGame(slot){
    AudioSys.ensure(); AudioSys.startDrone();
    const data = (slot===0) ? Save.loadAutosave() : Save.loadSlot(slot);
    if(!data){ AudioSys.tone(160,"sawtooth",0.12,0.12); return; }
    Save.apply(data);
    this.state="PLAY";
    UI.setHudVisible(true);
    UI.showScreen("none");
    document.getElementById("menu").classList.remove("active");
    Save.autosave("loaded");
  },

  setPause(on){
    if(on){
      if(this.state!=="PLAY") return;
      this.state="PAUSE";
      document.getElementById("pauseSub").textContent = `TIME: ${Stats.fmt()} • FEAR: ${Math.round(Player.fear)} • STATE: ${Enemy.state}`;
      UI.showScreen("pause");
    }else{
      if(this.state!=="PAUSE") return;
      this.state="PLAY";
      UI.showScreen("none");
      document.getElementById("screenPause").classList.remove("active");
    }
  },

  togglePause(){
    if(this.state==="PLAY") this.setPause(true);
    else if(this.state==="PAUSE") this.setPause(false);
  },

  interact(obj){
    AudioSys.ensure();

    if(obj.kind==="item"){
      const it=obj.ref;
      it.collected=true;

      if(it.type==="page"){
        Inventory.add("page",1);
        Journal.add("Collected a torn page.");
        AudioSys.tone(600,"sine",0.18,0.16);
      }
      if(it.type==="battery"){
        Flashlight.add(it.amount||25);
        Journal.add(`Picked up battery +${it.amount||25}%.`);
        AudioSys.tone(520,"sine",0.10,0.10);
      }
      if(it.type==="medkit"){
        Inventory.add("medkit",1);
        Journal.add("Found a medkit.");
        AudioSys.tone(420,"sine",0.08,0.10);
      }
      if(it.type==="key"){
        Inventory.add(it.keyId,1);
        Journal.add(`Picked up KEY: ${it.keyId}.`);
        AudioSys.tone(520,"square",0.06,0.10);
        // quest update
        if(Quest.get("find_key")?.status==="active"){
          Quest.set("find_key",{ status:"done" });
          Quest.set("unlock_door",{ status:"active" });
        }
      }
      if(it.type==="talisman"){
        Inventory.add("talisman",1);
        Journal.add("A talisman… it feels warm.");
        // small passive fear resist
        Player.fear = Math.max(0, Player.fear-18);
        AudioSys.tone(740,"sine",0.10,0.12);
      }
      if(it.type==="note"){
        Journal.add(`Note: ${it.text}`);
        AudioSys.tone(400,"square",0.08,0.09);

        // if note gives code
        if(it.givesCodeFor){
          const d=World.doorById(it.givesCodeFor);
          if(d){
            // quest update
            if(Quest.get("find_code")?.status==="active"){
              Quest.set("find_code",{ status:"done" });
              Quest.set("unlock",{ status:"active" });
              Journal.add("You can try the code on the exit door.");
            }
          }
        }
      }

      // noise on pickup
      NoiseSystem.emit(Player.x,Player.y, 25, 320, "pickup");
      Save.autosave("pickup");
      return;
    }

    if(obj.kind==="hide"){
      // toggle hide
      if(Player.hidden){
        Player.setHidden(false,null);
      }else{
        Player.setHidden(true, obj.ref.id);
      }
      Save.autosave("hide");
      return;
    }

    if(obj.kind==="door"){
      const d=obj.ref;
      if(d.open) return;

      if(d.locked){
        // key-locked
        if(d.keyId){
          if(Inventory.has(d.keyId,1)){
            Inventory.remove(d.keyId,1);
            d.unlocked=true; d.open=true;
            Journal.add("Door unlocked with key.");
            AudioSys.tone(660,"sine",0.12,0.12);
            NoiseSystem.emit(d.x,d.y, 65, 520, "door");
            Save.autosave("door_unlocked");

            if(Quest.get("unlock_door")?.status==="active"){
              Quest.set("unlock_door",{ status:"done" });
              Quest.set("escape",{ status:"active" });
            }
          }else{
            Journal.add("Door is locked. Need a key.");
            AudioSys.tone(160,"sawtooth",0.10,0.10);
          }
          return;
        }

        // code-locked
        if(d.code){
          if(Quest.get("unlock")?.status==="active"){
            CodeLock.open(d);
          }else{
            Journal.add("A keypad. You don't know the code yet.");
            AudioSys.tone(160,"sawtooth",0.10,0.10);
          }
          return;
        }
      }else{
        d.open=true;
        AudioSys.tone(520,"sine",0.08,0.10);
        NoiseSystem.emit(d.x,d.y, 55, 520, "door");
        Save.autosave("door_open");
      }
    }
  },

  checkQuestProgress(){
    const def=Chapter.def();

    // pages quest
    const q=Quest.get("find_pages");
    if(q && q.status==="active"){
      const pages = Inventory.items["page"]||0;
      if(pages >= (q.needPages||3)){
        Quest.set("find_pages",{ status:"done" });
        Quest.set("exit",{ status:"active" });
        Journal.add("All pages collected. Find the exit.");
        Save.autosave("quest_pages");
      }
    }

    // if exit locked by pages quest
    if(Quest.get("exit")?.status==="active"){
      const door=World.doorById(World.exit.doorId);
      if(door && !door.open){
        // if gate not locked, open automatically when pages done
        door.open=true;
        door.unlocked=true;
      }
    }

    // exit checks when escape objective is active
    const escape = Quest.get("escape") || Quest.get("exit");
    if(escape && escape.status==="active"){
      const door=World.doorById(World.exit.doorId);
      if(door && door.open && World.isAtExit(Player.x,Player.y)){
        escape.status="done";
        this.completeChapter();
      }
    }
  },

  completeChapter(){
    this.state="PAUSE";
    Save.autosave("chapter_complete");
    Chapter.unlockNext();

    const prog=Save.getProgress();
    prog.lastChapter = Chapter.idx;
    Save.setProgress(prog);

    document.getElementById("doneSub").textContent = `CHAPTER: ${Chapter.name()}`;
    document.getElementById("doneStats").innerHTML =
      `TIME: ${Stats.fmt()}<br>`+
      `DEATHS: ${Stats.deaths}<br>`+
      `SCARES: ${Stats.scares}<br>`+
      `STEPS: ${Stats.steps}<br>`+
      `ITEMS: ${Object.keys(Inventory.items).length}`;

    // enable next button only if exists
    const nextBtn=document.getElementById("btnNextChapter");
    nextBtn.disabled = (Chapter.idx+1 >= Chapter.defs.length);

    UI.showScreen("complete");
  },

  objectiveMarker(){
    const def=Chapter.def();
    // choose target by active quest
    const active=Quest.list.find(q=>q.status==="active");
    if(!active){ UI.marker(0,0,""); return; }

    // for pages: nearest uncollected page
    if(active.id==="find_pages"){
      let best=null, bd=Infinity;
      for(const it of World.items){
        if(it.type!=="page" || it.collected) continue;
        const d=dist(Player.x,Player.y,it.x,it.y);
        if(d<bd){ bd=d; best=it; }
      }
      if(best){ UI.marker(best.x,best.y,"PAGE"); return; }
    }

    // find key: marker -> key item
    if(active.id==="find_key"){
      const it=World.items.find(i=>i.type==="key" && !i.collected);
      if(it){ UI.marker(it.x,it.y,"KEY"); return; }
    }

    // find code: marker -> note
    if(active.id==="find_code"){
      const it=World.items.find(i=>i.type==="note" && i.givesCodeFor && !i.collected);
      if(it){ UI.marker(it.x,it.y,"NOTE"); return; }
    }

    // unlock door / escape -> door / exit
    const door=World.doorById(World.exit.doorId);
    if(door && !door.open){
      UI.marker(door.x+door.w/2, door.y+door.h/2, "DOOR");
      return;
    }
    UI.marker(World.exit.x, World.exit.y, "EXIT");
  },

  update(dt){
    if(this.state!=="PLAY") return;

    Stats.tick(dt);

    // autosave timer
    this.autosaveTimer += dt;
    if(this.autosaveTimer >= 30){
      this.autosaveTimer=0;
      Save.autosave("timer_30s");
    }

    NoiseSystem.update(dt);
    NoiseSystem.calcPlayerNoise();

    Player.update(dt);
    Flashlight.update(dt);
    Focus.update(dt);
    Enemy.update(dt);

    // heartbeat overlay + panic
    AudioSys.heartbeat(dt, Player.fear);

    // camera follow + shake
    const tx=Player.x - this.canvas.width/2;
    const ty=Player.y - this.canvas.height/2;
    this.cam.x = lerp(this.cam.x, tx, clamp(dt*5,0,1));
    this.cam.y = lerp(this.cam.y, ty, clamp(dt*5,0,1));

    if(this.shake>0){
      const m=this.shakeMult ?? 1;
      this.cam.x += (Math.random()-0.5)*this.shake*m;
      this.cam.y += (Math.random()-0.5)*this.shake*m;
      this.shake *= 0.9;
      if(this.shake<0.5) this.shake=0;
    }

    // triggers
    for(const t of World.triggers){
      if(t.fired && t.once) continue;
      if(rectContains(t.rect, Player.x, Player.y)){
        t.fired=true;
        Spook.run(t.action);
        if(t.once) Save.autosave("trigger");
      }
    }


// ambient + tension (game-feel)
const ch=Chapter.def();

// tension based on enemy proximity (0..1)
const dE = dist(Player.x,Player.y, Enemy.x,Enemy.y);
const targetT = clamp(1 - dE/360, 0, 1);
this.tension += (targetT - this.tension) * 0.08;

// heartbeat already exists (fear), but add extra fear pressure when very close
if(dE < 140) Player.fear = clamp(Player.fear + dt*6.0, 0, 100);

// ambient random spook chance (legacy)
if(Math.random() < (ch.ambience?.spookChance||0)){
  Spook.run("WHISPER");
}

// library-style ambient: drips + spatial whispers
this.amb.dripT -= dt;
this.amb.whisperT -= dt;

if(this.amb.dripT <= 0){
  Spook.run("DRIP");
  this.amb.dripT = rand(6.0, 18.0);
}
if(this.amb.whisperT <= 0){
  // low probability to avoid spam
  if(Math.random() < 0.55) Spook.run("WHISPER3D");
  this.amb.whisperT = rand(10.0, 26.0);
}

    // interact prompt target
    const target=World.getNearestInteractable(Player.x,Player.y);
    InteractHold.setTarget(target);
    if(target){
      UI.setInteract(true, `[HOLD E] ${target.name || "INTERACT"}`);
    }else{
      UI.setInteract(false);
      UI.setHold(0);
    }

    InteractHold.update(dt);

    // quest progression
    this.checkQuestProgress();
    UI.updateBars();
    UI.updateObjective();

    // objective marker
    this.objectiveMarker();
  },

  draw(){
    const ctx=this.ctx;
    ctx.clearRect(0,0,this.canvas.width,this.canvas.height);
    ctx.fillStyle="#050505";
    ctx.fillRect(0,0,this.canvas.width,this.canvas.height);

    ctx.save();
    ctx.translate(-this.cam.x, -this.cam.y);

    // floor base per chapter
    if(Chapter.def().id==="library"){
      // wood-like planks
      ctx.fillStyle="rgba(18,12,8,0.55)";
      ctx.fillRect(0,0,World.size.w,World.size.h);
      ctx.strokeStyle="rgba(255,255,255,0.05)";
      ctx.lineWidth=2;
      ctx.beginPath();
      for(let y=0;y<World.size.h;y+=38){ ctx.moveTo(0,y); ctx.lineTo(World.size.w,y); }
      ctx.stroke();
    }
    // floor grid subtle
    ctx.strokeStyle="#151515";
    ctx.lineWidth=2;
    ctx.beginPath();
    for(let x=0;x<World.size.w;x+=100){ ctx.moveTo(x,0); ctx.lineTo(x,World.size.h); }
    for(let y=0;y<World.size.h;y+=100){ ctx.moveTo(0,y); ctx.lineTo(World.size.w,y); }
    ctx.stroke();

    // walls
    for(const w of World.walls){
      // drop shadow
      ctx.fillStyle="rgba(0,0,0,0.85)";
      ctx.fillRect(w.x+14,w.y+14,w.w,w.h);

      if(w.kind==="shelf" && Chapter.def().id==="library"){
        // bookshelf look
        ctx.fillStyle="rgba(30,18,10,0.95)";
        ctx.fillRect(w.x,w.y,w.w,w.h);

        // top trim
        ctx.fillStyle="rgba(60,38,20,0.95)";
        ctx.fillRect(w.x,w.y,w.w,6);

        // shelves / rows
        const rows = Math.max(2, Math.floor(w.h/120));
        for(let r=1;r<rows;r++){
          const yy = w.y + (w.h/rows)*r;
          ctx.fillStyle="rgba(0,0,0,0.35)";
          ctx.fillRect(w.x, yy-2, w.w, 4);
        }

        // book spines (subtle)
        const cols = Math.max(2, Math.floor(w.w/40));
        for(let c=0;c<cols;c++){
          const xx = w.x + (w.w/cols)*c;
          const bw = (w.w/cols)-6;
          const bh = Math.min(28, (w.h/rows)-18);
          for(let r=0;r<rows;r++){
            const yy = w.y + (w.h/rows)*r + 12;
            ctx.fillStyle = `rgba(${90+((c*17+r*11)%60)}, ${50+((c*9+r*7)%40)}, ${30+((c*5+r*13)%30)}, 0.55)`;
            ctx.fillRect(xx+3, yy, bw, bh);
          }
        }
      }else{
        // generic wall block
        ctx.fillStyle="#000";
        ctx.fillRect(w.x,w.y,w.w,w.h);
        ctx.fillStyle="#222";
        ctx.fillRect(w.x,w.y,w.w,4);
      }
    }

    // hide spots
    for(const h of World.hide){
      ctx.fillStyle="rgba(30,10,10,0.45)";
      ctx.fillRect(h.x,h.y,h.w,h.h);
      ctx.fillStyle="rgba(138,0,0,0.55)";
      ctx.fillRect(h.x,h.y,3,h.h);
    }

    // doors
    for(const d of World.doors){
      ctx.fillStyle = d.open ? "rgba(60,20,20,0.20)" : "rgba(10,0,0,0.90)";
      ctx.fillRect(d.x,d.y,d.w,d.h);
      ctx.fillStyle = d.open ? "rgba(138,0,0,0.20)" : "rgba(138,0,0,0.75)";
      ctx.fillRect(d.x,d.y,3,d.h);
    }

    // exit circle
    ctx.beginPath();
    ctx.arc(World.exit.x,World.exit.y,World.exit.r,0,Math.PI*2);
    ctx.strokeStyle="rgba(138,0,0,0.25)";
    ctx.lineWidth=3;
    ctx.stroke();

    // items
    for(const it of World.items){
      if(it.collected) continue;
      ctx.shadowBlur=16;
      if(it.type==="page"){ ctx.fillStyle="#ffffaa"; ctx.shadowColor="yellow"; }
      else if(it.type==="battery"){ ctx.fillStyle="#d8c37a"; ctx.shadowColor="#d8c37a"; }
      else if(it.type==="medkit"){ ctx.fillStyle="#7aaad8"; ctx.shadowColor="#7aaad8"; }
      else if(it.type==="key"){ ctx.fillStyle="#ffffff"; ctx.shadowColor="#ffffff"; }
      else if(it.type==="talisman"){ ctx.fillStyle="#ffcc66"; ctx.shadowColor="#ffcc66"; }
      else { ctx.fillStyle="#ffffff"; ctx.shadowColor="#ffffff"; }

      ctx.beginPath();
      ctx.arc(it.x,it.y,8,0,Math.PI*2);
      ctx.fill();
      ctx.shadowBlur=0;
    }

    // noise events (debug)
    if(UI.debug){
      for(const n of NoiseSystem.events){
        ctx.beginPath();
        ctx.arc(n.x,n.y,n.radius*n.life,0,Math.PI*2);
        ctx.strokeStyle="rgba(255,255,255,0.08)";
        ctx.lineWidth=2;
        ctx.stroke();
      }
    }

    // enemy
    ctx.save();
    ctx.translate(Enemy.x,Enemy.y);
    const ox=(Math.random()-0.5)*(Enemy.state==="CHASE"?6:2);
    const oy=(Math.random()-0.5)*(Enemy.state==="CHASE"?6:2);
    ctx.fillStyle=`rgba(50,0,0,${0.7+Math.random()*0.25})`;
    ctx.fillRect(-18+ox,-18+oy,36,36);
    ctx.fillStyle="red";
    ctx.fillRect(-10+ox,-6+oy,6,6);
    ctx.fillRect(4+ox,-6+oy,6,6);
    ctx.restore();

    // player
    ctx.save();
    ctx.translate(Player.x,Player.y);

    // shadow
    ctx.fillStyle="rgba(0,0,0,0.45)";
    ctx.beginPath(); ctx.ellipse(0,12,12,6,0,0,Math.PI*2); ctx.fill();

    // stick figure (line character)
    const alpha = Player.hidden ? 0.28 : 0.95;
    const col = Player.hidden ? `rgba(180,180,180,${alpha})` : `rgba(220,220,220,${alpha})`;
    ctx.strokeStyle = col;
    ctx.lineWidth = 3;
    ctx.lineCap = "round";
    ctx.lineJoin = "round";

    const w = Player.walk||0;
    const phase = Math.sin(w);
    const arm = phase * 8;
    const leg = -phase * 10;
    const breath = Math.sin((Player.idleT||0)*2.2) * 1.8;
    const idleSway = Math.sin((Player.idleT||0)*1.4) * 0.8;

    // head
    ctx.beginPath();
    ctx.arc(idleSway,-18+breath,7,0,Math.PI*2);
    ctx.stroke();

    // body
    ctx.beginPath();
    ctx.moveTo(idleSway,-11+breath);
    ctx.lineTo(idleSway,6+breath);
    ctx.stroke();
    // arms (flashlight pose / swing)
    const hasFlash = (Flashlight.on && Flashlight.battery>0 && !Player.hidden);
    const swing = arm*0.22;

    if(hasFlash){
      // left arm close to body
      ctx.beginPath();
      ctx.moveTo(-6, -2);
      ctx.lineTo(-10, 3 + swing);
      ctx.stroke();

      // right arm points toward facing direction holding flashlight
      const fx = Math.cos(Player.dirAngle) * 18;
      const fy = Math.sin(Player.dirAngle) * 18;

      ctx.beginPath();
      ctx.moveTo(6, -2);
      ctx.lineTo(6 + fx*0.55, -2 + fy*0.55);
      ctx.lineTo(6 + fx*0.9, -2 + fy*0.9);
      ctx.stroke();

      // flashlight tip glow
      ctx.fillStyle = `rgba(255,255,240,${Player.hidden?0.0:0.35})`;
      ctx.beginPath();
      ctx.arc(6 + fx*0.95, -2 + fy*0.95, 3.2, 0, Math.PI*2);
      ctx.fill();
    }else{
      // relaxed swing
      ctx.beginPath();
      ctx.moveTo(-10, -2);
      ctx.lineTo(10, -2);
      ctx.stroke();

      ctx.beginPath();
      ctx.moveTo(-10, -2);
      ctx.lineTo(-14, 2 + swing);
      ctx.moveTo(10, -2);
      ctx.lineTo(14, 2 - swing);
      ctx.stroke();
    }

    // legs (swing)
    ctx.beginPath();
    ctx.moveTo(idleSway,6+breath);
    ctx.lineTo(idleSway-7, 18+breath + leg*0.12);
    ctx.moveTo(idleSway,6+breath);
    ctx.lineTo(idleSway+7, 18+breath - leg*0.12);
    ctx.stroke();

    // direction indicator
    ctx.strokeStyle = `rgba(255,255,255,${Player.hidden?0.08:0.18})`;
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(0,0);
    ctx.lineTo(Math.cos(Player.dirAngle)*18, Math.sin(Player.dirAngle)*18);
    ctx.stroke();

    ctx.restore();

    ctx.restore();

    // fog overlay (screen-space)
    const fog = clamp((Game.chapterFogBase||0.85) * (Game.fogMult||0.85), 0.15, 1.6);
    const a0=clamp(0.18*fog,0,1);
    const a1=clamp(0.85*fog,0,1);
    const a2=clamp(0.98*fog,0,1);
    const g=ctx.createRadialGradient(
      this.canvas.width/2, this.canvas.height/2, 100,
      this.canvas.width/2, this.canvas.height/2, 900
    );
    g.addColorStop(0, `rgba(5,5,5,${a0})`);
    g.addColorStop(0.5, `rgba(5,5,5,${a1})`);
    g.addColorStop(1, `rgba(5,5,5,${a2})`);
    ctx.fillStyle=g;
    ctx.fillRect(0,0,this.canvas.width,this.canvas.height);

    // flashlight cone
    if(Flashlight.on && Flashlight.battery>0 && !Player.hidden){
      const cx=this.canvas.width/2;
      const cy=this.canvas.height/2;
      ctx.save();
      ctx.translate(cx,cy);
      ctx.rotate(Player.dirAngle);

      ctx.beginPath();
      ctx.moveTo(0,0);
      ctx.arc(0,0,560,-0.35,0.35);
      ctx.closePath();
      ctx.clip();

      const lg=ctx.createRadialGradient(0,0,20,0,0,560);
      lg.addColorStop(0,"rgba(255,255,240,0.16)");
      lg.addColorStop(0.28,"rgba(0,0,0,0)");
      lg.addColorStop(1,"rgba(0,0,0,0)");

      ctx.globalCompositeOperation="screen";
      ctx.fillStyle=lg;
      ctx.fillRect(-700,-700,1400,1400);
      ctx.restore();
      ctx.globalCompositeOperation="source-over";
    }

    // debug overlay
    if(UI.debug){
      const dbg=document.getElementById("debug");
      dbg.innerHTML =
        `FPS: —<br>`+
        `STATE: ${Game.state}<br>`+
        `CHAPTER: ${Chapter.name()}<br>`+
        `P: ${Math.round(Player.x)},${Math.round(Player.y)}<br>`+
        `E: ${Math.round(Enemy.x)},${Math.round(Enemy.y)} (${Enemy.state})<br>`+
        `DETECTION: ${Math.round(Enemy.detection)}<br>`+
        `NOISE: ${Math.round(Player.noise)}<br>`+
        `FEAR: ${Math.round(Player.fear)}<br>`;
    }
  },

  loop(t){
    const dt = clamp((t-this.last)/1000, 0, 0.05);
    this.last=t;

    // apply settings to canvas each frame if changed
    this.canvas.style.imageRendering = this.pixelate ? "pixelated" : "auto";

    if(this.state==="PLAY") this.update(dt);

    // draw always (menu still shows background world)
    this.draw();

    requestAnimationFrame((tt)=>this.loop(tt));
  }
};

/* ===================== WIRE UP NON-SCREEN SHOW ===================== */
(function(){
  // small helper: UI.showScreen("none")
  const orig=UI.showScreen.bind(UI);
  UI.showScreen = function(which){
    if(which==="none"){
      ["screenLoading","screenPause","screenSettings","screenSave","screenChapter","screenCode","screenComplete"].forEach(id=>{
        document.getElementById(id).classList.remove("active");
      });
      document.getElementById("menu").classList.remove("active");
      return;
    }
    return orig(which);
  };
})();

/* ===================== INIT MENU + GAME ===================== */
window.Inventory = Inventory; // for onclick use medkit

window.onload=()=>{
  Game.init();

  // menu init needs after menu exists
  setTimeout(()=>{
    if(Save.hasAny()) document.getElementById("btnContinue").style.display="block";
  }, 50);

  // Pause screen actions
  document.getElementById("btnDoneMenu").addEventListener("click",()=>UI.showScreen("menu"));
};

/* ===================== GLOBAL UI BUTTONS OUTSIDE GAME ===================== */
document.getElementById("btnSaveBack").addEventListener("click",()=>UI.showScreen("menu"));

/* ===================== BIND MENU INIT AFTER BOOT ===================== */
setTimeout(()=>{
  MenuUI.init();
}, 600);
