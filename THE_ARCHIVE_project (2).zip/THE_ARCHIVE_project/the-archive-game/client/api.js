"use strict";

/**
 * RemoteDB adapter (optional)
 * - Works with server/server.js in this project
 * - Endpoints:
 *   GET  /api/ping
 *   GET  /api/save/:key          (key = "autosave" | "1" | "2" | "3")
 *   POST /api/save/:key  { data }
 *   GET  /api/latest-slot
 */
(function(){
  const RemoteDB = {
    enabled: false,

    async ping(){
      try{
        const r = await fetch("/api/ping", { cache:"no-store" });
        if(!r.ok) return false;
        const j = await r.json();
        return !!j?.ok;
      }catch(e){
        return false;
      }
    },

    async ensure(){
      if(this.enabled) return true;
      this.enabled = await this.ping();
      return this.enabled;
    },

    async latestSlot(){
      if(!(await this.ensure())) return null;
      try{
        const r = await fetch("/api/latest-slot", { cache:"no-store" });
        const j = await r.json();
        return (j && j.ok) ? j.slot : null;
      }catch(e){
        return null;
      }
    },

    async load(key){
      if(!(await this.ensure())) return null;
      const k = (key === 0 || key === "autosave") ? "autosave" : String(key);
      try{
        const r = await fetch(`/api/save/${encodeURIComponent(k)}`, { cache:"no-store" });
        const j = await r.json();
        return (j && j.ok) ? (j.data || null) : null;
      }catch(e){
        return null;
      }
    },

    async save(key, data){
      if(!(await this.ensure())) return false;
      const k = (key === 0 || key === "autosave") ? "autosave" : String(key);
      try{
        const r = await fetch(`/api/save/${encodeURIComponent(k)}`, {
          method: "POST",
          headers: { "Content-Type":"application/json" },
          body: JSON.stringify({ data })
        });
        const j = await r.json();
        return !!(j && j.ok);
      }catch(e){
        return false;
      }
    }
  };

  window.RemoteDB = RemoteDB;
})();
